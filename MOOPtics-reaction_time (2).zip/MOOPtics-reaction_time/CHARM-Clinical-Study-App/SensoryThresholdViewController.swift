//
//  SensoryThresholdViewController.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 10/11/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit
import MessageUI
//import CoreHaptics



/*
 File info
CSV file - digitally sent
    - put in cloud - Mooptics Google Drive
    - have developer sign in (allow developers to receive data, patients to send data)
 vibration sent: felt y/n
 distraction sent: felt y/n
 want lab to be able to access data (but not user)
    - ex. data imported from study app imported into developer app
 */

extension Notification.Name {
    static let vibrationGameOver = Notification.Name("vibrationGameOver")
    static let nBackGameOver = Notification.Name("nBackGameOver")
}
    

class SensoryThresholdViewController: BaseSensoryThresholdPresenter, SensoryThresholdSetup, UITableViewDelegate, UITableViewDataSource, MFMailComposeViewControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    var instructionsButton: UIButton!
    var shapeScale = CGFloat(1.0)
    var dropdownNValueTable: UITableView!
    var dropDownDisplayed = false

    let nValues = [1]
    var nValueLabel: UILabel!
    var nValueButton: UIButton!
    /*
    var ageTextField: UITextField!
    var agePicker: UIPickerView!
    var agePickerValues = [0] + Array(18...80)

    var participantAge: Int!
    
    var genderTextField: UITextField!
    var genderPicker: UIPickerView!

    var genderPickerValues = ["Choose One", "Female", "Male", "Transgender Female", "Transgender Male", "Non-Binary", "Prefer not to Answer", "Other (Please Input Answer)"]
    var participantGender: String!
    */
    var subjectTextField: UITextField!
    var subjectPicker: UIPickerView!
    var subjectPickerValues = Array(0...80)
    var subjectNum: Int!
    
    var conditionTextField: UITextField!
    var conditionPicker: UIPickerView!
    var conditionPickerValues = ["Choose one", "Walking", "Sitting"]
    var participantCondition: String!
    
    var countdownLabel: UILabel!
    var upcomingTest: Int?
    
    var vibrationGameManager: GameManager!
    var nBackGameManager: GameManager!
    
    var playAgainButton: UIButton!
    var completionLabel: UILabel!
    
    var scoreTitles: [UILabel]!
    var scoreScores: [UILabel]!
    
    //uncomment after testing
    let hapticTeamEmail = "moopticsresearch@gmail.com"
    //let hapticTeamEmail = "alexislowber16@gmail.com" /for testing
    
    var trialDesc: String!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        delegate = self
    }
    
    init(whichTest: Int) {
        self.upcomingTest = whichTest
        super.init(nibName: nil, bundle: nil)
        delegate = self
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        delegate = self
    }
    
    
    override func viewDidLoad() {
        view.backgroundColor = .systemGray4
        self.navigationController?.navigationBar.barTintColor = .systemGray

        NotificationCenter.default.addObserver(self, selector: #selector(displayResults), name: .vibrationGameOver, object: vibrationGameManager)
        
        NotificationCenter.default.addObserver(self, selector: #selector(displayResults), name: .nBackGameOver, object: nBackGameManager)
        
        demographicSurvey()
    }

    override func viewDidDisappear(_ animated: Bool) {
        // Notifies viewcontroller that its view is about to be removed from a view hierarchy
        // self.navigationController?.popViewController(animated: true)
        NotificationCenter.default.removeObserver(self)
    }
    
    /* ***** Demographic Survey Methods ****** */
    
    func demographicSurvey() {
        surveyInstructions()
        makePickers()
        //makeSurveyEntries(identity: 0)
        makeSurveyEntries(identity: 1)
        //makeSurveyEntries(identity: 2)
    }
    
    func surveyInstructions() {
        let xOffset = self.view.frame.width*0.1
        let yOffset = self.view.frame.height*0.13
        let height = self.view.frame.height*0.20
        let surveyInstructions = UILabel(frame: CGRect(x: xOffset, y: yOffset, width: self.view.frame.width - xOffset*2, height: height))
        
        surveyInstructions.text = "Please enter your information:"
        surveyInstructions.numberOfLines = 2
        surveyInstructions.font = UIFont.systemFont(ofSize: 30)
        
        self.view.addSubview(surveyInstructions)
    }
    
    func makePickers() {
        let xOffset = self.view.frame.width*0.1
        let pickerFrame = CGRect(x: xOffset, y: self.view.frame.height*0.7, width: self.view.frame.width - xOffset*2, height: self.view.frame.height*0.3)

        /*
        agePicker = UIPickerView(frame: pickerFrame)
        agePicker.delegate = self
        agePicker.dataSource = self
        agePicker.tag = 0
        
        genderPicker = UIPickerView(frame: pickerFrame)
        genderPicker.delegate = self
        genderPicker.dataSource = self
        genderPicker.tag = 1

        */
        subjectPicker = UIPickerView(frame: pickerFrame)
        subjectPicker.delegate = self
        subjectPicker.dataSource = self
        subjectPicker.tag = 1
        
        /*
        conditionPicker = UIPickerView(frame: pickerFrame)
        conditionPicker.delegate = self
        conditionPicker.dataSource = self
        conditionPicker.tag = 2
        */
    }
    
    func makeSurveyEntries(identity: Int) {
        //Label
        let xOffset = self.view.frame.width*0.1
        
  //      var yOffset = identity == 0 ? self.view.frame.height*0.20 + self.view.frame.height*0.20 : ageTextField.frame.maxY + self.view.frame.height*0.10
        var yOffset: CGFloat
        /*
        if identity == 0 {
            yOffset = self.view.frame.height*0.20 + self.view.frame.height*0.20
        }
        else if identity == 1 {
            yOffset = ageTextField.frame.maxY + self.view.frame.height*0.10
        }
        else {
            yOffset = ageTextField.frame.maxY + self.view.frame.height*0.25
        }
        
        let height = self.view.frame.height*0.05
        let label = UILabel(frame: CGRect(x: xOffset, y: yOffset, width: self.view.frame.width*0.2, height: height))

        if identity == 0 {
            label.text = "Age:"
        }
        else if identity == 1 {
            label.text = "Gender:"
        }
        else {
            label.text = "Condition:"
        }
 */
        if identity == 1 {
            yOffset = self.view.frame.height*0.20 + self.view.frame.height*0.20
        } else {
            yOffset = subjectTextField.frame.maxY + self.view.frame.height*0.10
        }
        
        let height = self.view.frame.height*0.05
        let label = UILabel(frame: CGRect(x: xOffset, y: yOffset, width: self.view.frame.width*0.2, height: height))

        if identity == 1 {
            label.text = "Subject Number:"
        }
        else {
            label.text = "Condition:"
        }
        //label.text = identity == 0 ? "Age:" : "Gender:"
        
        label.font = label.font.withSize(23)
        label.sizeToFit()
        self.view.addSubview(label)
        
        //Text Field
        let gapX = self.view.frame.width*0.05
        let textField = UITextField(frame: CGRect(x:label.frame.maxX + gapX, y: yOffset, width: self.view.frame.width - (xOffset*2 + label.frame.width + gapX), height: height))
        textField.layer.borderWidth = 1.0
        textField.layer.cornerRadius = 8.0
        textField.backgroundColor = UIColor.white
        textField.layer.borderColor = UIColor.black.cgColor
        textField.tintColor = UIColor.clear //make the blinking cursor invisible
        textField.delegate = self

        /*
        if identity == 0 {
            ageTextField = textField
            textField.inputView = agePicker
        } else if identity == 1 {
            genderTextField = textField
            textField.inputView = genderPicker
            genderTextField.addTarget(self, action: #selector(self.resetGenderInput), for: .touchUpOutside)
        }

        else {
            conditionTextField = textField
            textField.inputView = conditionPicker
        }
        */
        
        if identity == 1 {
            subjectTextField = textField
            textField.inputView = subjectPicker
        }
        else {
            conditionTextField = textField
            textField.inputView = conditionPicker
        }
        
        self.view.addSubview(textField)
    }
    
    /*
    @objc func resetGenderInput() {
        genderTextField.inputView = genderPicker
        genderTextField.tintColor = UIColor.systemBlue
    }

 */
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        /*
        if pickerView.tag == 0 {
            participantAge = agePickerValues[row]
            ageTextField.text = "  \(agePickerValues[row])"
        } else if pickerView.tag == 1 {
            participantGender = genderPickerValues[row]
            if genderPickerValues[row] == "Other (Please Input Answer)" {
                genderTextField.inputView = nil
                genderTextField.text = "  Enter Gender Identity"
                genderTextField.tintColor = UIColor.systemBlue //make cursor visible
            } else {
                genderTextField.text = "  \(genderPickerValues[row])"
            }
        }

        else {
            participantCondition = conditionPickerValues[row]
            conditionTextField.text = "  \(conditionPickerValues[row])"
        }
        */
        if pickerView.tag == 1 {
            subjectNum = subjectPickerValues[row]
            subjectTextField.text = "  \(subjectPickerValues[row])"
        }
        else {
            participantCondition = conditionPickerValues[row]
            conditionTextField.text = "  \(conditionPickerValues[row])"
        }
        
        self.view.endEditing(true)
        
        /*
        if participantAge != nil && participantGender != nil && participantCondition != nil{
            setupNextButton()
            nextButton.addTarget(self, action: #selector(self.setupTestMenu), for: .touchUpInside)
        }
        */
        if subjectNum != nil {
            setupNextButton()
            nextButton.addTarget(self, action: #selector(self.setupTestMenu), for: .touchUpInside)
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = UILabel()

        /*
        if pickerView.tag == 0 {
            label.text = String(agePickerValues[row])
        } else if pickerView.tag == 1 {
            label.text = String(genderPickerValues[row])
        }
        else {
            label.text = String(conditionPickerValues[row])
        }
        */
        if pickerView.tag == 1 {
            label.text = String(subjectPickerValues[row])
        } else {
            label.text = String(conditionPickerValues[row])
        }

   //     label.text = pickerView.tag == 0 ? String(agePickerValues[row]) : String(genderPickerValues[row])
        
        label.font = label.font.withSize(20)
        label.textAlignment = .center
        label.sizeToFit()
        return label
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
        textField.resignFirstResponder()

        //resetGenderInput()
        //participantGender = genderTextField.text
      return true
    }
    
    //data source protocol funcions
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {

        // let res = pickerView.tag == 0 ? agePickerValues.count : genderPickerValues.count
        var res: Int
        /*
        if pickerView.tag == 0 {
            res = agePickerValues.count
        }
        else if pickerView.tag == 1 {
            res = genderPickerValues.count
        }
        else {
            res = conditionPickerValues.count
        }
 */
        if pickerView.tag == 1 {
            res = subjectPickerValues.count
        } else {
            res = conditionPickerValues.count
        }
        return res
    }
    
    /* ****** End Demographic Survey Picker Vew Methods ****** */


    @objc func setupTestMenu() {
        clearView()
        
        nextButton.removeTarget(self, action: nil, for: .allEvents)
        

        // upcomingTest = 0  // commented out to all for initializing
        
        setupViewComponents()
        
        setupResponseButtons(numTest: self.upcomingTest) //this was previously uncommented
        
        //uncomment this when not testing!!!!!
        //gameManager = GameManager(totNumTrials: nValueSetting + 20)
        
        //before: totNumTrials: nValueSetting + 3

        //vibrationGameManager = GameManager(nBack: false, whichTest: self.upcomingTest!)
        //vibrationGameManager.delegate = self
        
        if self.upcomingTest != nil {
            nBackGameManager = GameManager(nBack: true, whichTest: upcomingTest!)
            nBackGameManager.delegate = self
        }
        else {
            print("No value for upcomingTest")
            nBackGameManager = GameManager(nBack: true,whichTest: -1)
            nBackGameManager.delegate = self
        }
    }
    
    @objc func launchTest(sender: UIButton) {
        sender.pulse()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {() in
            self.clearView()
            self.countdownAndRun()
        })
    }
    
    
    override func clearView() {
        super.clearView()
        nextButton.removeFromSuperview()
    }
     
    
    func startGame() {
        //self.view.addSubview(nValLabel)
        //self.view.addSubview(trialValLabel)

        //self.view.addSubview(shapeButton)
        self.view.addSubview(vibrationButton)
        
        makeHeaderLabels(trialNumber: 0)
        nBackGameManager.runGame()
        
    }
    
    func countdownAndRun() {
        clearView()
        
        self.navigationItem.leftBarButtonItem = nil
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        let sideLength = self.view.frame.width*0.2
        countdownLabel = UILabel(frame: CGRect(x: (self.view.frame.maxX - sideLength)/2.0, y: (self.view.frame.maxY - sideLength)/2.0, width: sideLength, height: sideLength))
        countdownLabel.font = UIFont.systemFont(ofSize: sideLength)
        countdownLabel.text = "3"
        countdownLabel.textAlignment = .center
        self.view.addSubview(countdownLabel)
        
        _ = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCountdown(sender:)), userInfo: nil, repeats: true)
    }
    
    @objc func updateCountdown(sender: Timer) {
        let currNum = Int(countdownLabel.text!)
        if currNum == 1 {
            sender.invalidate()
            countdownLabel.removeFromSuperview()
            startGame()
        } else {
            countdownLabel.text = String(currNum! - 1)
        }
        
    }

    /*
    @objc func moveToNextTest() {
        for x in nBackGameManager.dataArray {
            print(x) //REMOVE THIS WHEN NOT TESTING
        }
        
        clearView()
        
        upcomingTest = 1
        setupViewComponents()
    }

    */

    @objc func displayResults(notification: Notification) {
        //remove next button
        /*
        if let data = notification.userInfo as? [String: [Datapoint]]
            {
                //TODO: use data from gameManager.dataArray
            }
        */

        /*
        if self.upcomingTest == 1 {
            for x in nBackGameManager.dataArray {
                print(x)
            }
        }
        */
        
        clearView()
        makeReturnHomeButton()
        makePlayAgainButton()   // Currently a useless function

        recordScores()
        
        showCompletionMessage()



    }
    
    func recordScores() {
        guard MFMailComposeViewController.canSendMail() else {
            NSLog("Device does not support sending mail via MFMailComposeViewController")
            return
        }
        
        //let csvVibrationData = nBackGameManager.dataArray.joined(separator: "\n").data(using: .utf8)
        //let csvNBackData = vibrationGameManager.dataArray.joined(separator: "\n").data(using: .utf8)
        
        // let demographicInfo = "\(String(describing: participantAge))\n\(String(describing: participantGender))\n\(String(describing: participantCondition))\n\(String(describing: vibrationGameManager.vibSet))\n"
        
        let demographicInfo = "\n\n\(String(describing: subjectNum))\n"

        let csvNBackData = (demographicInfo + nBackGameManager.dataArray.joined(separator: "\n")).data(using: .utf8)
        
        //let csvVibrationData = (demographicInfo + vibrationGameManager.dataArray.joined(separator: "\n")).data(using: .utf8)
         
        guard csvNBackData != nil else {
            NSLog("Unable to obtain data object for email.")
            return
        }

        /*
        guard let csvVibrationData = nBackGameManager.dataArray.joined(separator: "\n").data(using: .utf8), let csvNBackData = vibrationGameManager.dataArray.joined(separator: "\n").data(using: .utf8) else {
            NSLog("Unable to obtain data object for email.")
            return
        }*/
        //TODO: also send file with name, sex, age, scores to csv file on apprr
        
        let mailComposer = MFMailComposeViewController()
        mailComposer.mailComposeDelegate = self
        mailComposer.setSubject("Mooptics Data") //add subject's naname

        let emailMessage = "Attached file contains Reaction Time Test Data" + "\n\nSubject Number: " + String(subjectNum!)
        mailComposer.setMessageBody(emailMessage, isHTML: false)
        mailComposer.setToRecipients([hapticTeamEmail])

        let subj_str = String(subjectNum)
        
        if upcomingTest == 0 {// visual
            trialDesc = "v"
        }
        else if upcomingTest == 1{  //aud
            trialDesc = "a"
        }
        else if upcomingTest == 2{
            trialDesc = "h"
        }
        else if upcomingTest == 3{
            trialDesc = "va"
        }
        else if upcomingTest == 4{
            trialDesc = "vh"
        }
        else if upcomingTest == 5{
            trialDesc = "ah"
        }
        else if upcomingTest == 6{
            trialDesc = "avh"
        }
        
        let filename = trialDesc + "_reactionTimeData" + subj_str + ".csv"
        
        mailComposer.addAttachmentData(csvNBackData!, mimeType: "text/csv", fileName: filename)


        self.present(mailComposer, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch result {
        case .cancelled:
            NSLog("Mail cancelled by user.")
        case .failed:
            NSLog("Mail send failure.")
        case .saved:
            NSLog("Mail saved by user.")
        case .sent:
            NSLog("Mail successfully sent.")
        @unknown default:
            NSLog("Unknown mail compose result.")
        }
        
        controller.dismiss(animated: true, completion: nil)
    }
 
    
    
    func makeReturnHomeButton() {
        let returnHomeButton = UIButton(frame: CGRect(x: nextButton.frame.minX, y: nextButton.frame.minY, width: nextButton.frame.width, height: nextButton.frame.height))
        returnHomeButton.setTitle("Return Home", for: .normal)
        returnHomeButton.backgroundColor = nextButton.backgroundColor
        returnHomeButton.titleLabel?.font = nextButton.titleLabel?.font
        returnHomeButton.setTitleColor(.black, for: .normal)
        returnHomeButton.addTarget(self, action: #selector(returnHome), for: .touchUpInside)
        self.view.addSubview(returnHomeButton)
    }
    
    @objc func returnHome(sender: UIButton) {
        sender.pulse()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {() in
            self.navigationController?.popViewController(animated: true)
        })
        
    }
    
    func makePlayAgainButton() {
        playAgainButton = UIButton(frame: CGRect(x: nextButton.frame.minX, y: nextButton.frame.minY - nextButton.frame.height*1.25, width: nextButton.frame.width, height: nextButton.frame.height))

        playAgainButton.isHidden = true     // Comment this to put in play again button
        // Uncomment this to put in play again button
        /*
        playAgainButton.setTitle("Play Again", for: .normal)
        playAgainButton.backgroundColor = nextButton.backgroundColor
        playAgainButton.titleLabel?.font = nextButton.titleLabel?.font
        playAgainButton.setTitleColor(.black, for: .normal)
        playAgainButton.addTarget(self, action: #selector(playAgain(sender:)), for: .touchUpInside)
        self.view.addSubview(playAgainButton)

         */
    }
    
    @objc func playAgain(sender: UIButton) {
        //REVISIT THIS -- CHANGE UPCOMING TEST VALUE
        sender.pulse()
        
        nBackGameManager.reset()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {() in
            self.clearView()
            //self.trialNumber = 0
            self.countdownAndRun()
        })
    }
    
    func showCompletionMessage() {
        let height = self.view.frame.height*0.20
        completionLabel = UILabel(frame: CGRect(x: nValLabel.frame.minX, y: nValLabel.frame.minY, width: trialValLabel.frame.maxX - nValLabel.frame.minX, height: height))
        completionLabel.font = UIFont.systemFont(ofSize: 30)

        completionLabel.text = "Great job! You have completed the assessment."
        completionLabel.numberOfLines = 4
        self.view.addSubview(completionLabel)
    }
    
    func showGameStats() {
        
        let xOffset = self.view.frame.width*1/10
        //3 offsets, scores = 4 title = 3
        let yOffset = (playAgainButton.frame.minY - completionLabel.frame.maxY)/10
        let width = self.view.frame.width*2/5

        let currVibrationTitle = UILabel(frame: CGRect(x: xOffset, y: completionLabel.frame.maxY + yOffset, width: width, height: yOffset*1.5))
        currVibrationTitle.text = "Vibration Task"
        
        let currVisionTitle = UILabel(frame: CGRect(x: self.view.frame.maxX - width - xOffset, y: completionLabel.frame.maxY + yOffset, width: width, height: yOffset*1.5))
        currVisionTitle.text = "Vision Task"
        
        
        let currVibrationScore = UILabel(frame: CGRect(x: currVibrationTitle.frame.minX, y: currVibrationTitle.frame.maxY, width: width, height: yOffset*2))
        currVibrationScore.text = "\(nBackGameManager.correctHapticAnswers!)/\(nBackGameManager.hapticEventNumber!)"
        let currVisionScore = UILabel(frame: CGRect(x: currVisionTitle.frame.minX, y: currVisionTitle.frame.maxY, width: width, height: yOffset*2))
        currVisionScore.text = "\(nBackGameManager.correctShapeAnswers!)/\(nBackGameManager.totNBackShapes!)"
        

        /*
        let bestTitle = UILabel(frame: CGRect(x: currVibrationTitle.frame.minX, y: currVibrationScore.frame.maxY + yOffset, width: width*2, height: yOffset*1.5))
        bestTitle.text = "Previous high scores for n = \(nValueSetting)"
        
        let bestVibrationScore = UILabel(frame: CGRect(x: currVibrationScore.frame.minX, y: bestTitle.frame.maxY, width: width, height: yOffset*2))
        bestVibrationScore.text = "---"
        let bestVisionScore = UILabel(frame: CGRect(x: currVisionScore.frame.minX, y: bestTitle.frame.maxY, width: width, height: yOffset*2))
        bestVisionScore.text = "---"
        */
        
        for title in [currVibrationTitle, currVisionTitle] {
            title.font = UIFont.systemFont(ofSize: yOffset*0.75)
            title.textAlignment = .center
            self.view.addSubview(title)
        }
        
        for score in [currVibrationScore, currVisionScore] {
            score.font = UIFont.systemFont(ofSize: yOffset*2)
            score.textAlignment = .center
            self.view.addSubview(score)
        }

    }
    
    
    
    /* ***********TABLE VIEW METHODS*********** */
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nValues.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //consider using UIMenu to do a pull-down menu (type of UI control)
        let cell = dropdownNValueTable.dequeueReusableCell(withIdentifier: "cellID", for: indexPath)
        
        if #available(iOS 14.0, *) {
            var configuration = cell.defaultContentConfiguration()
            configuration.text = String(nValues[indexPath.row])
            configuration.textProperties.alignment = .center
            cell.contentConfiguration = configuration
        } else {
            // Fallback on earlier versions
            cell.textLabel?.text = String(nValues[indexPath.row])
            cell.textLabel?.textAlignment = .center
        }

        cell.backgroundColor = .systemGray5
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        nValueSetting = nValues[indexPath.row]
        //nBackGameManager.setTotNumTrials(totNumTrials: nValueSetting + 20)
        toggleDropDown()
        
    }
    
    
    /* ***********SETTING UP VIEW COMPONENTS*********** */
    
    override func setupViewComponents() {
        super.setupViewComponents()
        
        setupNextButton()
        self.view.addSubview(nextButton)

        nextButton.addTarget(self, action: #selector(launchTest), for: .touchUpInside)
        //nextButton.addTarget(self, action: #selector(nextButtonResponse), for: .touchUpInside)
        

        if upcomingTest! < 0 {      // Instructions never run. To allow instructions for nback only, flip the sign
            setupInstructionsButton()
            
            setupNValueObjects()
            
            setupSettingsOptions()
        }

    }
    
    func setupInstructionsButton() {
        let diameter = self.view.frame.width*0.3
        //let x = self.view.frame.width*0.1
        
        //let y = self.view.frame.height*0.2
        let x = nextButton.frame.width - diameter/2.0
        let y = nextButton.frame.minY - diameter*1.25
        instructionsButton = UIButton(frame: CGRect(x: x, y: y, width: diameter, height: diameter))
        
        instructionsButton.layer.cornerRadius = diameter/2
        
        instructionsButton.backgroundColor = UIColor(red: 0.0, green: 175/255, blue: 219/255, alpha: 1.0)
        
        instructionsButton.setTitle("Instructions", for: .normal)
        
        instructionsButton.addTarget(self, action: #selector(displayInstructions(sender:)), for: .touchUpInside)
        
        self.view.addSubview(instructionsButton)
    }
    
    
    @objc func displayInstructions(sender: UIButton) {
        sender.pulse()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {() in
            
            //present the instructions view modally
            let child = InstructionsViewController() as UIViewController
            self.present(child, animated: true, completion: nil)
        })
    }
    
    
    func setupNValueObjects() {
        let height = self.view.frame.height*0.1
        let width = self.view.frame.width*0.3
        let x = nextButton.frame.minX
        let y = self.view.frame.height*0.25
        
        nValueLabel = UILabel(frame: CGRect(x: x, y: y, width: width, height: height*0.75))
        nValueLabel.text = "n ="
        nValueLabel.font = UIFont.systemFont(ofSize: height)
        nValueLabel.backgroundColor = .systemGray4
        
        self.view.addSubview(nValueLabel)
        
        let buttonWidth = self.view.frame.width*0.2
        nValueButton = UIButton(frame: CGRect(x: nextButton.frame.maxX - buttonWidth, y: y, width: buttonWidth, height: height))
        nValueButton.backgroundColor = .systemGray5
        nValueButton.setTitleColor(UIColor.black, for: .normal)
        
        nValueButton.setTitle(String(nValueSetting), for: .normal)
        nValueButton.titleLabel!.font = UIFont.systemFont(ofSize: height)
        //nValueButton.titleLabel!.adjustsFontSizeToFitWidth = true
        //nValueButton.titleLabel!.lineBreakMode = .byClipping
        nValueButton.addTarget(self, action: #selector(toggleDropDown), for: .touchUpInside)
        nValueButton.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        nValueButton.layer.shadowRadius = 3
        
        self.view.addSubview(nValueButton)
    }
    
    
    //allow users to choose a value of n
    func setupSettingsOptions() {
        var frame = dropDownExpandedFrame()
        frame.size = CGSize(width: frame.width, height: 0)
        
        dropdownNValueTable = UITableView(frame: frame, style: .plain)
        dropdownNValueTable.delegate = self
        dropdownNValueTable.dataSource = self
        dropdownNValueTable.register(UITableViewCell.self, forCellReuseIdentifier: "cellID")
        dropdownNValueTable.backgroundColor = .systemGray4
        dropdownNValueTable.rowHeight = dropDownExpandedFrame().height/CGFloat(nValues.count)
        
        dropdownNValueTable.separatorInset = UIEdgeInsets.zero
        
        dropdownNValueTable.layer.shadowColor = UIColor.black.cgColor
        dropdownNValueTable.layer.shadowOffset = CGSize(width: 0.0, height: 2)
        dropdownNValueTable.layer.shadowRadius = 2
        dropdownNValueTable.layer.shadowOpacity = 1.0
        
        self.view.addSubview(dropdownNValueTable)
        //use UIPickerView
        //oruse UIModalPresentationPopover property
    }
    
    func dropDownExpandedFrame() -> CGRect {
        let width = self.view.frame.width*0.2
        let height = self.view.frame.height*0.2
        let x = nextButton.frame.maxX - width
        let y = nValueButton.frame.maxY + 1.0
        
        let frame = CGRect(x: x, y: y, width: width, height: height)
        return frame
    }
    
    
    
    /* ***********UPDATING VIEW COMPONENTS*********** */
    
    @objc func toggleDropDown() {
        if dropDownDisplayed {
            //collapse view
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear, animations: {
                self.dropdownNValueTable.frame.size = CGSize(width: self.dropdownNValueTable.frame.width, height: 0)
                //self.dropdownNValueTable.numberOfRows(inSection: 1)
                self.nValueButton.setTitle(String(self.nValueSetting), for: .normal)
            }, completion: nil)
        } else {
            //expand view
            //dropdownNValueTable.reloadData()
            //self.dropdownNValueTable.reloadData()
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveLinear, animations: {
                self.dropdownNValueTable.frame = self.dropDownExpandedFrame()
                self.dropdownNValueTable.reloadData()
            }, completion: nil)
            
        }
        dropDownDisplayed = !dropDownDisplayed
    }
    
}
