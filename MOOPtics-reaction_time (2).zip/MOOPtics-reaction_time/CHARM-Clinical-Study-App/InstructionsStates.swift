//
//  InstructionsStates.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 10/11/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit


//TODO: make transitionText property for solo textviews w larger font
struct StateComponents {
    //let -1 = not there
    var header: String?
    //var trialHeader: Int?
    //var instructions: Int?
    var image: Int?
    var responseButtons: Int?
    var nextButton: Int?
    var prevButton: Int?
}

/*
struct TextEntry {
    var bolded: String?
    var normal: String
}
 */


let nBackInstructionStates: [StateComponents] = [
    StateComponents(header: "Vibration Task", image: nil, responseButtons: nil, nextButton: 0, prevButton: nil),

    //StateComponents(header: "Vibration Task", image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "Vibration Task and Shape-matching Task", image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),
    //StateComponents(header: "Shape-matching Task:", image: 0, responseButtons: nil, nextButton: 0, prevButton: nil),
    //StateComponents(header: nil, image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),
    //StateComponents(header: nil, image: 0, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "1", image: 1, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "1", image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "2", image: 3, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "2", image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "3", image: 3, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: "3", image: nil, responseButtons: 0, nextButton: 9, prevButton: nil),
    //StateComponents(header: "3", image: nil, responseButtons: 0, nextButton: 0, prevButton: nil),

    StateComponents(header: "4", image: 2, responseButtons: 0, nextButton: 0, prevButton: nil),
    StateComponents(header: nil, image: nil, responseButtons: 0, nextButton: 0, prevButton: nil)
]

let nBackTextDictionary: [String] = [
//    "Let’s start by testing how well you perceive vibrations.",
//    "We want to find out what is the lowest vibration that you can feel. \nYou will be presented with a series of vibrations, some of which you may or may not feel. If you feel a vibration, tap the red button below. If you cannot feel a vibration, do not press the button. This task will last for approximately 2 minutes.\n",
    "This task is a shape-matching task.\n\nThis task will be explained on the following pages.",
    //"First, let's look at the vibration sensing task.\n\nThe phone will vibrate at random intervals, and you should hit the red button on the right whenever you sense a vibration. \n\nNow, let's talk about the shape-matching task",
    "Shapes will appear on the screen at regular intervals. If a shape appears that matches the shape that was shown right before, press the blue button (the left button). \n\nLet's go through an example to help understand this",
    "The first trial shows you your first shape.\nSince this is just the first shape, there are no shapes from before to compare to, so there is no reason to press the button.\n\nKeep in mind that the first shape is a triangle!",
    "The screen will appear blank as you await your next shape.", // stopped editing here
    "The second trial shows you your second shape.\n\nSince this is not a triangle, it does not match the previous shape.\n\nYou can forget the first shape (the triangle), but now remember this shape.",
    "The screen will appear blank as you await your next shape.",
    "For this third shape, you must again correctly remember whether or not this shape is the same as the previous shape you were shown.\n\nThe previous shape was a square, so you SHOULD press the blue button!",
    "The screen will appear blank as you await your next shape.",
    "Again, you must correctly remember whether or not this shape is the same as the previous shape you were shown.\n\nRemember, the previous shape was a square, so this circle does not match the triangle, so you SHOULD NOT press the button!",
    "Now that you have an understanding of this assessment, it’s now time to start.\n\nTo respond to the shape-matching task, tap the blue button.",
    //"Filler",
    //"Filler",
    "Now that you get it, it’s now time to start the assessment."
]

/*
let textDictionary: [Int:TextEntry] = [
    0: TextEntry(bolded: "Absolute Threshold Test", normal: "Before we get started with the n-back tasks, let’s start by testing how well you perceive vibrations without cognitive load."),
    1: TextEntry(bolded: "Screening", normal: "We want to find out what is the lowest vibration that you can feel. This screening is not the true assessment.\nIn the next section, we will present you a series of vibrations. If you feel the vibration, tap the red button as seen below. If you cannot feel the vibration, do not press the button. You will have 1 second to respond to each vibration.\n"),
    2: TextEntry(bolded: "N-back task and Haptic Perception Task", normal: "It’s now time to start the real assessment! You will be performing two tasks at a time, one testing your cognition and one testing your perception."),
    3: TextEntry(bolded: "Haptic Perception Task", normal: "Just like in the Absolute Threshold Test, we want you to tap the red button below if you feel a vibration.\nHere’s the catch: the vibrations will be delivered at varying levels and times."),
    4: TextEntry(bolded: "N-back task:", normal: "We will use N-back tasks to test your cognition.You will be shown a series of shapes. Tap the blue button if the current shape matches the shape from n trials back. For example:"),
    5: TextEntry(bolded: nil, normal: "Let’s do a little practice with this n-back task."),
    6: TextEntry(bolded: nil, normal: "Note that n = 2. The first trial shows you your first shape. There are no shapes from 2 trials to compare to, so pressing the button will not work."),
    7: TextEntry(bolded: nil, normal: "The screen will appear blank as you await your next shape."),
    8: TextEntry(bolded: nil, normal: "The second trial shows you your first shape. There are no shapes from 2 trials to compare to, so, again, pressing the button will not work."),
    9: TextEntry(bolded: nil, normal: "The screen will appear blank as you await your next shape."),
    10: TextEntry(bolded: nil, normal: "For this third shape, the button finally works, but you should NOT press the button. Remember, 2 trials ago (1st trial), the shape was a triangle. This square does not match the triangle!"),
    11: TextEntry(bolded: nil, normal: "The screen will appear blank as you await your next shape."),
    12: TextEntry(bolded: nil, normal: "For this 4th shape, you SHOULD press the button. Remember, 2 trials ago (1st trial), the shape was a triangle. This shape matches that triangle!"),
    13: TextEntry(bolded: "", normal: "Now that you get it, it’s now time to start the assessment.")
]
*/
//let imageDictionary : [Int: UIImage] = [
    //0: makeThreeShapes()
//]

