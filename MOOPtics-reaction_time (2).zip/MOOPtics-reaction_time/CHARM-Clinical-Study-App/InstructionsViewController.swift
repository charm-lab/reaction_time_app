//
//  InstructionsViewController.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 10/24/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit

class InstructionsViewController: BaseSensoryThresholdPresenter, SensoryThresholdResponder {
    
    var header: UILabel!
    var instructions: UITextView!
    var viewNumber = 0
    var shapeScale = CGFloat(0.8)
    
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        delegate = self
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        delegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        shapeButton.isEnabled = false
        vibrationButton.isEnabled = false
    }
    
    override func setupViewComponents() {
        super.setupViewComponents()
        setupHeader()
        setupInstructions()
        
        setupNextButton()
        nextButton.addTarget(self, action: #selector(updateViewComponents(sender:)), for: .touchUpInside)
    }
    
    /* ***********SETTING UP VIEW COMPONENTS*********** */
    
    func setupHeader() {
        let width = self.view.frame.width*0.8
        let height = self.view.frame.height*0.05
        let x = (self.view.frame.width - width)/2.0
        let y = self.view.frame.height*0.05
        
        header = UILabel(frame: CGRect(x: x, y: y, width: width, height: height))
        
        updateHeader()
    }
    
    
    func setupInstructions() {
        
        let width = self.view.frame.width*0.8
        let height = self.view.frame.height*0.5
        let x = (self.view.frame.width - width)/2.0
        let y = header.frame.maxY + self.view.frame.height*0.03

        instructions = UITextView(frame: CGRect(x: x, y: y, width: width, height: height))
        
        instructions.isScrollEnabled = true
        //instructions.showsVerticalScrollIndicator = true
        instructions.textAlignment = .left
        instructions.backgroundColor = .systemGray4
        instructions.isEditable = false
        instructions.textContainerInset = UIEdgeInsets.zero
        instructions.textContainer.lineFragmentPadding = 0
        
        updateInstructions()

        //self.view.addSubview(instructions)
    }
    
    
    func makeThreeShapes() {
        
        let width = self.nextButton.frame.width*(1/4.5)
        let y = self.view.frame.height*0.5
        let height = width
        
        let triangle = UIImage(systemName: "arrowtriangle.up.fill", withConfiguration: UIImage.SymbolConfiguration(weight: .ultraLight))!
 
        //tint color property of UIImage not effective
        let circle = UIImage(systemName: "circle.fill", withConfiguration: UIImage.SymbolConfiguration(weight: .ultraLight))!
        
        let triangleOneView = UIImageView(frame: CGRect(x: nextButton.frame.minX, y: y, width: self.nextButton.frame.width/4.5, height: height))
        triangleOneView.image = triangle
        triangleOneView.tintColor = UIColor.white
        triangleOneView.isOpaque = false

        
        let circleView = UIImageView(frame: CGRect(x: nextButton.frame.minX + self.nextButton.frame.width*(1.75/4.5), y: y, width: width, height: height))
        circleView.image = circle
        circleView.tintColor = UIColor.white
        circleView.isOpaque = false
 
        
        let triangleTwoView = UIImageView(frame: CGRect(x: nextButton.frame.minX + self.nextButton.frame.width*(3.5/4.5), y: y, width: width, height: height))
        triangleTwoView.image = triangle
        triangleTwoView.tintColor = UIColor.white
        triangleTwoView.isOpaque = false
        
        self.view.addSubview(triangleOneView)
        self.view.addSubview(circleView)
        self.view.addSubview(triangleTwoView)
        
        imageViews = [triangleOneView, circleView, triangleTwoView]
        
        //put into make label function
        
        let labelY = triangleOneView.frame.minY - 50
        let labelFont = UIFont.boldSystemFont(ofSize: 20)
        
        var labelOneFrame = triangleOneView.frame
        labelOneFrame.origin = CGPoint(x: labelOneFrame.minX, y: labelY)
        let labelOne = UILabel(frame: labelOneFrame)
        labelOne.text = "1"
        labelOne.font = labelFont
        labelOne.textAlignment = .center
        
        var labelTwoFrame = circleView.frame
        labelTwoFrame.origin = CGPoint(x: labelTwoFrame.minX, y: labelY)
        let labelTwo = UILabel(frame: labelTwoFrame)
        labelTwo.text = "2"
        labelTwo.font = labelFont
        labelTwo.textAlignment = .center
        
        var labelThreeFrame = triangleTwoView.frame
        labelThreeFrame.origin = CGPoint(x: labelThreeFrame.minX, y: labelY)
        let labelThree = UILabel(frame: labelThreeFrame)
        labelThree.text = "3"
        labelThree.font = labelFont
        labelThree.textAlignment = .center
        labelThree.textColor = UIColor(red: 37/255, green: 142/255, blue: 142/255, alpha: 1.0)
        
        
        let nLabel = UILabel(frame: CGRect(x: triangleOneView.frame.minX - 60, y: labelY, width: 50, height: labelOne.frame.height))
        nLabel.text = "n = 2"
        nLabel.font = labelFont
        
        self.view.addSubview(labelOne)
        self.view.addSubview(labelTwo)
        self.view.addSubview(labelThree)
        self.view.addSubview(nLabel)
        
        imageLabels = [labelOne, labelTwo, labelThree, nLabel]
    
    }
    
    /* ***********UPDATING VIEW COMPONENTS*********** */
    
    override func clearView() {
        super.clearView()
        
        /*
        //clear instructions
        if self.view.subviews.contains(instructions) {
            instructions.removeFromSuperview()
        }
        
        //clear header
        if self.view.subviews.contains(header) {
            header.removeFromSuperview()
        }
         */
        /*
        if self.view.subviews.contains(shapeButton) {
            //set array of current views --> iterate through and delete
            for img in imageViews {
                img.removeFromSuperview()
            }
            imageViews = []
            for label in imageLabels {
                label.removeFromSuperview()
            }
        }
         */
    }
    
    
    func updateViewComponents(sender: UIButton?) {
        
        if sender != nil {
            sender!.pulse()
            viewNumber += 1
        }
        
        if viewNumber > nBackInstructionStates.count - 1 {
            dismiss(animated: true, completion: nil)
            return
        }
        
        clearView()
        updateHeader()
        updateInstructions()
        updateImage()
        updateResponseButtons()
        //updateNextButton()

    }

    //NOTE: this doesn't need objc!!!
    @objc func updateImage() {

//        //TODO: make image numbers into enum
//        let num = nBackInstructionStates[viewNumber].image
//        
//        switch num {
//        case 0:
//            makeThreeShapes()
//        case 1:
//            makeSingleShape(shapeName: "arrowtriangle.up.fill")
//        case 2:
//            makeSingleShape(shapeName: "circle.fill")
//        case 3:
//            makeSingleShape(shapeName: "squareshape.fill")
//        /*case 4:
//            //TODO: add hand positioning image
//            NSLog("Todo: add hand positioning image")
//        */
//        default:
//            NSLog("Reached case \(String(describing: num)) for updateImage function.")
//        }
    }
    
    
    func updateInstructions() {

        let height = nBackInstructionStates[viewNumber].image == nil ? self.view.frame.height*0.5 : self.view.frame.height*0.17
        
        instructions.frame = CGRect(x: instructions.frame.minX, y: instructions.frame.minY, width: instructions.frame.width, height: height)
        
        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 18)
        ]
        
        instructions.attributedText = NSAttributedString(string: nBackTextDictionary[viewNumber], attributes: attributes)
        
        self.view.addSubview(self.instructions)
        /*
        DispatchQueue.main.asyncAfter(deadline: .now(), execute: {() in
            self.view.addSubview(self.instructions)
            if nBackInstructionStates[self.viewNumber].image != nil {
                self.instructions.flashScrollIndicators()
            }
        })*/
        
        self.view.addSubview(instructions)
    }
    
    
    func updateResponseButtons() {
        guard nBackInstructionStates[viewNumber].responseButtons != nil else {
            return
        }
        
        self.view.addSubview(shapeButton)
        //self.view.addSubview(vibrationButton)
    }
    
    
    func updateHeader() {
        guard let str = nBackInstructionStates[viewNumber].header else {
            return
        }
        
        if !str.isEmpty && str.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil {
            //if str is a number, it represents a trial header
            if trialValLabel == nil {
                //if labels haven't been shown before, create labels
                let trialNumber = Int(str)!
                makeHeaderLabels(specialY: header.frame.minY, trialNumber: trialNumber)
            } else {

                // trialValLabel.text = "Trial \(str)"
                self.view.addSubview(nValLabel)
                self.view.addSubview(trialValLabel)
            }
            
        } else {
            //otherwise, str represents an instruction header
            let boldAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 30)
            ]
            let instructionHeader = NSAttributedString(string: str, attributes: boldAttributes)
            header.attributedText = instructionHeader
            
            self.view.addSubview(header)
        }
        
    }
    
}
