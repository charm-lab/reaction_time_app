//
//  TrialMenuViewController.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 9/28/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit
import SwiftUI

struct menuButtonInfo {
    var name: String
    var targetSelector: Selector
    var postition: Int
}

class TrialMenuViewController: UIViewController {
    
    let buttons = [UIButton(), UIButton(), UIButton()] //CHANGED
    var buttonInfo: [menuButtonInfo]!

    var baselineTest: SensoryThresholdViewController! = SensoryThresholdViewController(whichTest: 0)
    var nbackTest: SensoryThresholdViewController! = SensoryThresholdViewController(whichTest: 1)
    var practiceTest: SensoryThresholdViewController! = SensoryThresholdViewController(whichTest: 2)
    
    override init(nibName: String?, bundle: Bundle?) {
        super.init(nibName: nibName, bundle: bundle)
        buttonInfo = setupButtonInfo()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        buttonInfo = setupButtonInfo()
    }
    
    func setupButtonInfo() -> [menuButtonInfo] {

        // Just one test
        let reactInfo = menuButtonInfo(name: "Reaction Time", targetSelector: #selector(reactSelected(sender:)), postition: 1)
        buttonInfo = [reactInfo]
        return buttonInfo
    }
    
    override func viewDidLoad() {
        self.view.backgroundColor = .white
        self.navigationController?.isNavigationBarHidden = true
        makeButtons()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.view.backgroundColor = .white
        self.navigationController?.isNavigationBarHidden = true
    }
    
    func makeButtons() {
    
        for info in buttonInfo {
            let frame = getButtonFrame(orderNumber: info.postition)
            let button = UIButton(frame: frame)
            button.tintColor = .systemBlue
            
            button.backgroundColor = .systemBlue
            button.setTitle(info.name, for: .normal)
            button.layer.cornerRadius = 10

            button.addTarget(self, action: info.targetSelector, for: .touchUpInside)
            self.view.addSubview(button)
            //self.view.addSubview(label)
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func getButtonFrame(orderNumber: Int) -> CGRect {
        let width = self.view.frame.width*0.7

        let height = self.view.frame.height*0.075
        let x = (self.view.frame.width - width)/2.0
        //let y = self.view.frame.height*0.2*CGFloat(orderNumber) - height
        let y = self.view.frame.height*0.12*CGFloat(orderNumber+1) - height
        let frame = CGRect(x: x, y: y, width: width, height: height)
        
        return frame
    }
    
    
    //consider putting all responses into one function and then add views inside switch statement

    @objc func reactSelected(sender: UIButton) {
        //TODO: fill in
        sender.pulse()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7, execute: {() in

            self.show(SensoryThresholdViewController(whichTest: 0), sender: self)
        })
    }
  
}

extension UIButton {
    func pulse() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.7
        pulse.fromValue = 0.93
        pulse.toValue = 1.0
       
        layer.add(pulse, forKey: nil)
        
        //completion()
    }
    
    func grow() {
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 0.7
        pulse.fromValue = 1.2
        pulse.toValue = 1.0
       
        layer.add(pulse, forKey: nil)
        
        //completion()
    }
}

