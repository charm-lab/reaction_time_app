//
//  MechanicalTestingSettingsView.swift
//  iPhone Haptics Test
//
//  Created by Bryce Huerta on 7/16/20.
//  Copyright © 2020 Bryce Huerta and Alexis Lowber. All rights reserved.
//

import SwiftUI
import CoreHaptics
import CoreMotion

struct MechanicalTestingSettingsView: View {
    // Haptic Engine
    @State private var engine: CHHapticEngine?
    //
    let motion = CMMotionManager()
    // Slider variables to adjust Haptic settings
    @State var currentIntensity = 0.5
    @State var currentSharpness = 0.5
    @State var numPulse = 1.0
    @State var timeBetween = 0.5
    @State var signalDuration = 1.0
    @State var timeToPlay = 3.0
    var body: some View {
        VStack {
            /*
            //navigation view
            NavigationView {
                    .navigationBarItems(trailing:
                        Button("Back") {
                            body.removeFromSuperview()
                        }
                    )
            }*/

            // Top level text
            Text("iPhone Haptics Test")
                .onAppear(perform: prepareHaptics)
            HStack {
                // Haptic Intensity Slider
                Text("Intensity: \(String(format: "%.2f", currentIntensity))")
                Slider(value: $currentIntensity, in: 0...1, step: 0.05)
                    .accentColor(.blue)
                    .padding()
            }
            HStack {
                // Haptic Sharpness Slider
                Text("Sharpness: \(String(format: "%.2f", currentSharpness))")
                Slider(value: $currentSharpness, in: 0...1, step: 0.05)
                    .accentColor(.blue)
                    .padding()
            }
            HStack {
                // Haptic Duration Slider
                Text("Pulse Duration: \(String(format: "%.1f", signalDuration))")
                Slider(value: $signalDuration, in: 0.1...2, step: 0.1)
                    .accentColor(.blue)
                    .padding()
            }
            HStack {
                // Number of pulses created slider
                Text("Number of Pulses: \(String(format: "%.0f", numPulse))")
                Slider(value: $numPulse, in: 1...10, step: 1.0)
                    .accentColor(.blue)
                    .padding()
            }
            HStack {
                // Time between each pulse slider
                Text("Time Between Pulses: \(String(format: "%.1f", timeBetween))")
                Slider(value: $timeBetween, in: 0...2, step: 0.1)
                    .accentColor(.blue)
                    .padding()
            }
            HStack {
                // Countdown timer
                Text("Time to Play: \(String(format: "%.0f", timeToPlay))")
                Slider(value: $timeToPlay, in: 0...10, step: 1)
                    .accentColor(.red)
                    .padding()
            }
            .padding()
            // Go button
            Button(action:
                {
                    // Countdown delay
                    DispatchQueue.main.asyncAfter(deadline: .now() + self.timeToPlay) {
                        if self.motion.isAccelerometerAvailable {
                            self.motion.accelerometerUpdateInterval = 0.01
                            self.motion.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
                                if let myData = data{
                                   print(data)
                                }
                            }
                        }
                        self.customHaptics()
                    }
                    self.motion.stopAccelerometerUpdates()
            }) {
                Text("GO")
            }
        }
    }
    
    // Prepares Haptic Engine
    func prepareHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return}
        
        do {
            self.engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("There was an error creating the Haptic Engine: \(error.localizedDescription)")
        }
    }
    
    func customHaptics() {
        var events = [CHHapticEvent]()
        let intensity = CHHapticEventParameter(parameterID:.hapticIntensity, value: Float(currentIntensity))
        let sharpness = CHHapticEventParameter(parameterID:.hapticSharpness, value: Float(currentSharpness))
        for i in 0...Int((self.numPulse - 1)) {
            let event = CHHapticEvent(eventType:.hapticContinuous, parameters: [intensity, sharpness], relativeTime: (timeBetween + signalDuration)*Double(i), duration: signalDuration)
            events.append(event)
        }
        
        do {
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine?.makeAdvancedPlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            print("Failed to play pattern")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MechanicalTestingSettingsView()
    }
}
