//
//  SensoryThresholdPresentationViewController.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 10/25/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit


protocol SensoryThresholdSetup {
    var shapeScale: CGFloat { get }
    func setupViewComponents()
    //func setupTrialHeader()
}

@objc protocol SensoryThresholdInteractionResponse {
    @objc func updateViewComponents(sender: UIButton?)
    @objc func updateImage()
}

typealias SensoryThresholdResponder = SensoryThresholdSetup & SensoryThresholdInteractionResponse

class BaseSensoryThresholdPresenter: UIViewController {
    //var delegate: SensoryThresholdResponder!
    var delegate: SensoryThresholdSetup!
    
    var shapeButton: UIButton!
    var vibrationButton: UIButton!
    var nextButton: UIButton!
    var imageViews: [UIImageView]!
    var imageLabels: [UILabel]!
    var trialValLabel: UILabel!
    var nValLabel: UILabel!
    var nValueSetting = 1
    //var trialNumber = 0 //remove this???
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func viewDidLoad() {
        view.backgroundColor = .systemGray4
        self.navigationController?.navigationBar.barTintColor = .systemGray4
        
        delegate.setupViewComponents()
        delegate.setupViewComponents()
        //delegate.updateViewComponents(sender: nil)
    }
    
    

    func makeSingleShape(shapeName: String, stimIntensity: Int) {
        var opacity: CGFloat
        if stimIntensity == 1{
            opacity = 0.9
        }
        else{
            opacity = 0.1
        }
        //let sysName = triangle? "arrowtriangle.up.fill"
        
        let shape = UIImage(systemName: shapeName, withConfiguration: UIImage.SymbolConfiguration(weight: .ultraLight))!
    
        //let width = self.view.frame.width*0.7
        //let height = width
        let height = self.view.frame.height*0.42*delegate.shapeScale
        let width = height
        let y = self.view.frame.height*0.1 // prev = 0.32       // to change shape height
        let x = (self.view.frame.width - width)/2.0
        
        
        let frame = CGRect(x: x, y: y, width: width, height: height)
        
        let shapeView = UIImageView(frame: frame)
        shapeView.image = shape
        shapeView.tintColor = UIColor.white
        shapeView.isOpaque = false

        //opacity command. Temporary, will have to be moved further to a more specific level
        shapeView.alpha = opacity

        
        self.view.addSubview(shapeView)
        
        imageViews = [shapeView]
    }
    
    /* ***********SETTING UP VIEW COMPONENTS*********** */
    
    func setupViewComponents() {
        //delegate.setupTrialHeader()
        //makeHeaderLabels()
        setupImage()
        setupResponseButtons(numTest: 1)
    }
    
    
    /*func setupTrialHeader() {
        //TODO: fill in
    }*/
    
    
    func setupImage() {
        imageViews = []
        imageLabels = []
    }
    

    func setupResponseButtons(numTest: Int?) {
        //TODO: fill in
        let diameter = self.view.frame.width*0.8
        //let height = width
        //let shapeX = (self.view.frame.width - diameter)/2 - diameter*0.75// - width)
        let vibrationX = (self.view.frame.width - diameter)/2 //+ width)
        let y = self.view.frame.height*0.55*delegate.shapeScale //prev: 0.8  // to change button height
        
//        shapeButton = UIButton(frame: CGRect(x: shapeX, y: y, width: diameter, height: diameter))
//        shapeButton.backgroundColor = UIColor(red: 113/255, green: 158/255, blue: 242/255, alpha: 1.0)
//        shapeButton.layer.cornerRadius = diameter/2
        
        vibrationButton = UIButton(frame: CGRect(x: vibrationX, y: y, width: diameter, height: diameter))
        vibrationButton.backgroundColor = UIColor(red: 224/255, green: 83/255, blue: 83/255, alpha: 1.0)
        vibrationButton.layer.cornerRadius = diameter/2
        
        //TODO: addTargets and make pulse
    }
    
    func setupNextButton() {
        let width = self.view.frame.width*0.5
        let height = self.view.frame.height*0.08 //0.2 max
        let x = (self.view.frame.width - width)/2.0
        let y = self.view.frame.height - height*2.25 //prev: 1.5
        //let y = instructions.frame.maxY + height/2.0
         
        nextButton = UIButton(frame: CGRect(x: x, y: y, width: width, height: height))
        nextButton.setTitle("Next", for: .normal)
        nextButton.backgroundColor = UIColor(red: 113/255, green: 158/255, blue: 242/255, alpha: 1.0)
        //nextButton.tintColor =  UIColor(red: 113, green: 158, blue: 242, alpha: 1.0)
        nextButton.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        nextButton.setTitleColor(.black, for: .normal)
        
        self.view.addSubview(nextButton)
    }
    
    func makeHeaderLabels(specialY: CGFloat? = nil, trialNumber: Int) {
        let statusBarFrameY = self.view.window?.windowScene?.statusBarManager?.statusBarFrame.maxY ?? 0
        
        let y = specialY == nil ? statusBarFrameY + self.view.frame.height/10.0 : specialY!
        let height = self.view.frame.height*0.05
        let xOffset = self.view.frame.width/10.0
        let width = self.view.frame.width/2.0 - xOffset
        
        let nValFrame = CGRect(x: xOffset, y: y, width: width, height: height)
        nValLabel = UILabel(frame: nValFrame)
        nValLabel.font = UIFont.systemFont(ofSize: height)

        //nValLabel.text = "n = \(nValueSetting)"   // UNCOMMENT this after the study. This only applies when n is forced to be 1
        
        self.view.addSubview(nValLabel)
        
        let trialValFrame = CGRect(x: self.view.frame.maxX/2.0, y: y, width: width, height: height)
        trialValLabel = UILabel(frame: trialValFrame)
        trialValLabel .font = UIFont.systemFont(ofSize: height)
        trialValLabel.textAlignment = .right
        //trialValLabel.text = "Trial \(trialNumber)"   // Uncomment this to initialize header
        
        self.view.addSubview(trialValLabel)
 
        
    }
    
    /* ***********UPDATING VIEW COMPONENTS*********** */
    
    func clearView() {
        for view in self.view.subviews {
            if view != nextButton {
                view.removeFromSuperview()
            }
        }
    }
    /*
    func updateTrialHeader() {
        //TODO: fill in
    }*/
    
}
