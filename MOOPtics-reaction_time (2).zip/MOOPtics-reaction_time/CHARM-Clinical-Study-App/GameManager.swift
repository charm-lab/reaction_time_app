//
//  GameManager.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 12/23/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import UIKit
import CoreHaptics
import AVFoundation

enum Shape: Int, CaseIterable {
    //0 indicates no shape is shown
    case triangle = 1
    case circle
    case square
    //case rectangle
    case hexagon
    
    var description: String {
        switch self {
        case .triangle:
            return "arrowtriangle.up.fill"
        case .circle:
            return "circle.fill"
        case .square:
            return "squareshape.fill"
        //case .rectangle:
        //    return "rectangle.fill"
        case .hexagon:
            return "hexagon.fill"
        }
    }
}

struct Datapoint: CustomStringConvertible {
    
    var time: Float
    var shapeShown: Int
    var shapeButtonPressed: Int

    var vibrationButtonPressed: Int
    var audioIntensity: Int
    var hapticIntensity: Int
    var visualIntensity: Int
    
    var description: String {
        return "\(time), \(shapeShown), \(shapeButtonPressed), \(vibrationButtonPressed),\(audioIntensity),\(hapticIntensity),\(visualIntensity)"
    }
}

//make public class w/ data array public
//use notification center to signal end of game
class GameManager: SensoryThresholdInteractionResponse {
    
    var delegate: BaseSensoryThresholdPresenter!
    //var shapeScale: CGFloat
    var nBack: Bool
    
    var dataArray: [String]!
    var currDatapoint: Datapoint!
    
    var dataTimer: Timer!
    let dataRecordingRate = 0.001 //how often data is recorded (seconds)
    var shapeTimer: Timer?
    let shapeShownDuration = 0.500 + 0.300 //how logn shapes are shown (seconds) note: there is a fixed time to have shape appear and fade out.
    let timeBetweenShapes = 2.500
    var hapticTimer: Timer!
    let hapticDuration = 0.100 //how long each haptic is played (seconds)
    let hapticIntervalMin = 3.000 //minimum time between haptics (seconds)
    let hapticIntervalMax = 6.000 //maximum time between haptics (seconds)
    var randomInterval: Int!
    var numTrials = 5 // how many trials (how many repetitions for each intensity)
    
    let modalNum = 26   // How many different modality
    var modalityArr: [Int]!

    var hapticEngine: CHHapticEngine?
    var intensities: [Int]!
    
    var nBackShapes: [Shape]?
    var nBackShapeShown: Bool?
    var vibrationOccurred: Bool!
    
    var trialNumber: Int?
    //var totalNumTrials: Int?
    
    var correctShapeAnswers: Int?
    var totNBackShapes: Int?
    var correctHapticAnswers: Int!
    var hapticEventNumber: Int!
    

    var upcomingTest: Int?
    var intensitiesWindow: Int = 9
    
    let practiceTrials = 300
    var endPractice: Bool = false
    
    let setTime:Double = 45        //How long one set of 9 vibrations takes
    var currTimeArray:Array<Double> = []
    var prevShape = 1
    var nextShape = 0
    var nBackIOArray: Array<Int> = []
    
    var shapeInitTime: Double!
    var vibInitTime: Double!
    var intermediaryTime: Double = 0
    var prevInterTime: Double = 0
    
    var setSize: Int = 9
    let vibSet:Array<Float> = [0.1, 0.125, 0.15, 0.175, 0.2, 0.225, 0.25, 0.275, 0.3];
    
    var soundEffect: AVAudioPlayer?
    var audioTimer: Timer!
    
    var zeroTimer: Timer?
    /*
    init(nBack: Bool) {
        self.nBack = nBack
        self.upcomingTest = -1
        self.reset()
    }
    */
    
    //make failable initializer - if engine not set up, then fails
    init(nBack: Bool, whichTest: Int) {
        self.nBack = nBack
        self.upcomingTest = whichTest
        self.reset()
    }
    
    deinit {
        if hapticEngine != nil {
            hapticEngine?.stop(completionHandler: nil)
        }
    }


    func reset() {
        dataArray = ["Time, Shape Shown, Shape Button Pressed, Vibration Button Pressed,Audio Intensity,Haptic Instensity,Visual Intensity"]
        
        currDatapoint = Datapoint(time: 0, shapeShown: 0, shapeButtonPressed: 0, vibrationButtonPressed: 0, audioIntensity: 0, hapticIntensity: 0, visualIntensity: 0)
        
        trialNumber = 0
        
        nBackShapes = []
        nBackShapeShown = false
        vibrationOccurred = false
        
        correctShapeAnswers = 0
        totNBackShapes = 0
        correctHapticAnswers = 0
        hapticEventNumber = 0
        
        resetIntensities()
    }
    
    func resetIntensities() {

        intensities = [Int]()
        let totIntensities = numTrials*setSize
        for index in 1...totIntensities{
            if index%2 == 0{
                intensities += [1]
            }
            else{
                intensities += [2]
            }
        }
    }
    
    @objc func shapeResponse(sender: UIButton) {
        currDatapoint.shapeButtonPressed = 1
        //print("datapoint:", currDatapoint.shapeButtonPressed)

        sender.grow() //don't comment this
        if nBackShapeShown! {
            correctShapeAnswers! += 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {(
            self.currDatapoint.shapeButtonPressed = 0
        )})
        //print("datapoint:", currDatapoint.shapeButtonPressed)
    }
    
    @objc func vibrationResponse(sender: UIButton) {
        currDatapoint.vibrationButtonPressed = 1
        //print("datapoint:", currDatapoint.vibrationButtonPressed)
        if vibrationOccurred {
            correctHapticAnswers += 1
        }

        sender.grow() //don't comment this
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {(
            self.currDatapoint.vibrationButtonPressed = 0
        )})
        //print("datapoint:", currDatapoint.vibrationButtonPressed)
    }
    
    func runGame() {
        // Set the brightness and the volume
        UIScreen.main.brightness = 1.0
        
        setupHapticEngine()
        
        makeModArr()        // Refresh the modality array
        
        delegate.vibrationButton.addTarget(self, action: #selector(self.vibrationResponse(sender:)), for: .touchDown)
        delegate.vibrationButton.isEnabled = true
        
        dataTimer = Timer.scheduledTimer(timeInterval: dataRecordingRate, target: self, selector: #selector(recordData), userInfo: nil, repeats: true)
        
        hapticTimer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateHaptics), userInfo: nil, repeats: true)
    }
    
    @objc func recordData() {
        currDatapoint.time += Float(dataRecordingRate)
        dataArray.append(currDatapoint!.description)
        //print(currDatapoint!.description)
    }
    
    @objc func updateHaptics() {
        
        //if the next vibration interval has not been set
        if hapticTimer.timeInterval == 0.5 {
            let interval = pickTime()
            // print(interval)     // Uncomment for debugging
            hapticTimer.invalidate()
            hapticTimer = Timer.scheduledTimer(timeInterval: TimeInterval(interval), target: self, selector: #selector(updateHaptics), userInfo: nil, repeats: true)
            
        } else { //if it is time for the next vibration

            //check if game is over
            if modalityArr.isEmpty {
                // empty the intensities array (to help if this was a practice round)
                intensities = []
                
                //finish game
//                if nBack {
//                    shapeTimer!.invalidate()
//                    delegate.imageViews = []
//                }
                hapticTimer.invalidate()
                dataTimer.invalidate()
                
//                print(correctHapticAnswers!)
//                print(correctShapeAnswers!)
                
                //NotificationCenter.default.post(name: .gameOver, object: self, userInfo: ["data": dataArray])
                if nBack {
                    NotificationCenter.default.post(name: .nBackGameOver, object: self)
                } else {
                    NotificationCenter.default.post(name: .vibrationGameOver, object: self)
                }
                
                return
            }
            
            //this accounts for edge cases where the next haptic might come while the response period is still open
            endHapticResponsePeriod()
            
            // Determine which stimuli is played
            // 0 = V, 1=A, 2=H, 3=V+A, 4=V+H, 5=A+H, 6=A+H+V
            let modality = pickModality()
            
            switch modality{
            case 1:     // vis low
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 2:     // vis high
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 3:     // aud low
                playSound(stimIntensity: 2)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 4:     // aud high
                playSound(stimIntensity: 1)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 5:     // haptic low
                playHaptic(stimIntensity: 2)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 6:     // haptic high
                playHaptic(stimIntensity: 1)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 7:     // vis low, aud low
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playSound(stimIntensity: 2)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 8:     // v high, aud low
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playSound(stimIntensity: 2)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 9:     // vis low, aud high
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playSound(stimIntensity: 1)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 10:    // vis high, aud high
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playSound(stimIntensity: 1)
                currDatapoint.hapticIntensity = 0
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 11:    // vis low, hap low
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playHaptic(stimIntensity: 2)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 12:    // vis low, hap high
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playHaptic(stimIntensity: 1)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 13:    // vis high, hap low
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playHaptic(stimIntensity: 2)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 14:    // vis high, hap high
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                playHaptic(stimIntensity: 1)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 0
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 15:    // aud low, hap low
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 2)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 16:    // aud low, hap high
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 1)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 17:    // aud high, hap low
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 2)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 18:    // aud high, hap high
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 1)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 0
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 19:    // aud low, vis low, hap low
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 2)
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 20:    // aud low, vis low, hap high
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 1)
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 21:    // aud low, vis high , h low
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 1)
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 22:    // aud low, vis high, h high
                playSound(stimIntensity: 2)
                playHaptic(stimIntensity: 1)
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 2
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 23:    // aud high, vis low, hap low
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 2)
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 24:    // aud high, vis low, hap high
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 2)
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 2
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 25:    // aud high, vis high, hap low
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 1)
                showShape(opacity: 2)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 2
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            case 26:    // aud high, vis high, hap high
                playSound(stimIntensity: 1)
                playHaptic(stimIntensity: 1)
                showShape(opacity: 1)
                shapeTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(removeShape), userInfo: nil, repeats: true)
                currDatapoint.hapticIntensity = 1
                currDatapoint.audioIntensity = 1
                currDatapoint.visualIntensity = 1
                zeroTimer = Timer.scheduledTimer(timeInterval: TimeInterval(shapeShownDuration), target: self, selector: #selector(zeroRecording), userInfo: nil, repeats: false)
            default:
                print("A modality case isn't covered")
            }
            
            vibrationOccurred = true
            //perform(#selector(endHapticResponsePeriod), with: nil, afterDelay: 1.5)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {() in
                self.endHapticResponsePeriod()
            })
            hapticEventNumber += 1
            
            hapticTimer.invalidate()
            hapticTimer = Timer.scheduledTimer(timeInterval: TimeInterval(0.5), target: self, selector: #selector(updateHaptics), userInfo: nil, repeats: true)
        }
    }
    
    func endHapticResponsePeriod() {
        vibrationOccurred = false
    }

    func updateViewComponents(sender: UIButton?) {
        updateImage()
        //print("\(nBackIOArray.count) shape \(currDatapoint.time)")
        /*if trialNumber <= totalNumTrials {
            updateImage()
        }*/
        // updateTrialHeader()
    }
    
    func showShape(opacity: Int){
        self.delegate.makeSingleShape(shapeName: "squareshape.fill", stimIntensity: opacity)
        //self.currDatapoint.visualIntensity = opacity
    }
    
    @objc func removeShape(){
        DispatchQueue.main.async {
            self.delegate.imageViews[0].removeFromSuperview()
            self.currDatapoint.shapeShown = 0
            self.delegate.imageViews = []
        }
        
        shapeTimer!.invalidate()
    }
    
    func updateImage() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: {()

            let shapeNumToRun = self.generateShapeNum()  // This is technically repetitive (could use parameter nextShape), but this feels better. Feel free to change
            // print(shapeNumToRun)
            let randomShape = Shape(rawValue: shapeNumToRun)! // This is good, commented for testing

            //self.delegate.makeSingleShape(shapeName: randomShape.description)
            self.currDatapoint.shapeShown = randomShape.rawValue


            //note: trial number is updated after this function is called (so we look for 0 instead of 1)
            if self.trialNumber! > self.delegate.nValueSetting {
                if randomShape == self.nBackShapes![0] {
                    //UNCOMMENT FOR TESTING
                    //print("MATCH", randomShape, self.nBackShapes[0])
                    // self.delegate.shapeButton.pulse() //used for testing
                    self.nBackShapeShown = true
                    self.totNBackShapes! += 1
                    //TODO: record nback shape and test for user response
                } else {
                    //print(randomShape)
                    self.nBackShapeShown = false
                }
                self.nBackShapes!.removeFirst()
            }

            self.nBackShapes!.append(randomShape)
        })
    }
    
    /* Refined shape generation methods */
    func generateShapeNum() -> Int{
        let shapesPerSet = 45/3     // The number of shapes to show per vibration set, 45 sec/set divided by 3 sec per shape

        if nBackIOArray.isEmpty{
            shapeInitTime = Double(currDatapoint.time)
            if trialNumber! <= 1{
                // The leading values in the io matrix for the first IO matrix must be 0's equal to the nback value
                nBackIOArray = Array(repeating: 0, count: self.delegate.nValueSetting) + makeIOMatrix(arraySize: (shapesPerSet - self.delegate.nValueSetting))
                print("Initializing \(currDatapoint.time)")
            }
            else{
                nBackIOArray = makeIOMatrix(arraySize: shapesPerSet)
                print("Making shape array  \(currDatapoint.time)")

            }
        }
        // Now generate the shape
        if nBackIOArray[0] == 1{
            nextShape = prevShape
        }
        else if nBackIOArray[0] == -1{
            nextShape = 0
        }
        else{
            var possibleShapes = Array(1...Shape.allCases.count)    // scales with Shape cases
            possibleShapes.remove(at: (prevShape - 1))  // Using the fact that possible shapes is in numerical order, possibleShapes[0] = 1, etc.
            let index = Int.random(in: 0..<possibleShapes.count)
            nextShape = possibleShapes[index]
        }
        prevShape = nextShape
        nBackIOArray.remove(at: 0)  // to keep the array moving forward
        return nextShape
    }
    
    // Makes a matrix of 1's and 0's to determine when an nback occurs
    func makeIOMatrix(arraySize: Int) -> Array<Int>{
        var iOMatrix = Array(repeating: 0, count: arraySize)
        
        let numNbacks = 3         // number of nbacks in a set
        var pickFromArray = Array(0..<arraySize)
        var indexes:Array<Int> = []
        
        for _ in 1...numNbacks{
            let tempIndex = Int.random(in: 0..<pickFromArray.count)
            indexes += [pickFromArray[tempIndex]]
            pickFromArray.remove(at: tempIndex)
        }
        
        if trialNumber! < numTrials*15 {      // No nback in the last 2 extra shapes
            for i in indexes {
                iOMatrix[i] = 1
            }
        }
        
        print(iOMatrix)
        return iOMatrix
    }
    
    /* Refined timing methods */
    // Picks a new time
    func pickTime() -> Double{
        if currTimeArray.isEmpty{
            currTimeArray = makeNewTimeArray()
            //print("making time array \(currDatapoint.time)") // No longer necessary to see
            vibInitTime = Double(currDatapoint.time)
        }
        let index = Int.random(in: 0..<currTimeArray.count)
        var time = currTimeArray[index]
        
        // To randomize the placement of the vibration block within the shape set
        if currTimeArray.count == 9 && upcomingTest != 0 {
            intermediaryTime = time/2                   // Cut the first time in half
            time = prevInterTime + intermediaryTime     // Add this first half to the half from the last set
            vibInitTime += prevInterTime                // Adjust the unifying processes timing accordingly
            prevInterTime = intermediaryTime            // Carry on the value for next set
        }

        currTimeArray.remove(at: index)             // TODO: Move lower

        return time
    }
    
    // Makes a new time matrix totalling a given amount
    func makeNewTimeArray() -> Array<Double> {
        let centralNum:Double = self.setTime/9.0     // The number the timing will center around, Assuming we'll always have 9 vibrations
        let timingMax = (centralNum - hapticIntervalMin)    // So we never generate something lower than minimum
        var timeArray = Array(repeating:5.0, count:9)
        
        for i in 0...3{
            //generate a random number in the range
            let diff = Double.random(in: 0.6...timingMax)   // the 0.6 is to force variance
            let roundedDiff = round(diff * 10) / 10.0

            timeArray[i] -= roundedDiff
            timeArray[8-i] += roundedDiff      // Again, assuming size of 9
        }
        return timeArray
    }
    
    /* Haptic Engine Methods */
    func restartHapticEngine() {
        NSLog("Restarting haptic engine.")
        
        do {
            try self.hapticEngine!.start()
        } catch let restartError {
            NSLog("Failed to restart th ehaptic engine because \(restartError)")
        }
    }
    
    func setupHapticEngine() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics == true else {
            NSLog("Device does not support haptics.")
            //TODO: present error
            return
        }
        do {
            hapticEngine = try CHHapticEngine()
            try hapticEngine!.start()
        } catch let connectionError {
            fatalError("Could not establish a connection to the haptic server because \(connectionError)")
        }
        
        hapticEngine!.resetHandler = {
            self.restartHapticEngine()
        }
        
        hapticEngine!.stoppedHandler = { stoppedReason in
            NSLog("Haptic engine stopped because \(stoppedReason)")
            
            self.restartHapticEngine()
            }
    }
    

    func playSound(stimIntensity: Int){
        // Determine the volume
        var soundVol: Float
        if stimIntensity == 1 {
            soundVol = 0.1
        }
        else{
            soundVol = 0.01
        }
        //sound playing, all for testing
        let path = Bundle.main.path(forResource: "blip.wav", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        
        do{
            // Create audio player
            soundEffect = try AVAudioPlayer(contentsOf: url)
            soundEffect!.volume = soundVol
            soundEffect!.play()
        } catch {
            print("couldn't load file")
        }
        
        //record the sound instensity
        //currDatapoint.audioIntensity = stimIntensity
        //audioTimer = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(audioFinished), userInfo: nil, repeats: true)    }
    
    }
    
    func playHaptic(stimIntensity:Int){
        do {
            //TODO: switch to using dynamic parameters -- can make fewer players
            var intensityValue: Float
            if stimIntensity == 1{
                intensityValue = 1
            }
            else{
                intensityValue = 0.3
            }
            // print("\(intensities.count % 9) Intensity \(currDatapoint.time)") // comment when not testing
            let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: intensityValue)
            let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
            let event = CHHapticEvent(eventType: .hapticContinuous, parameters: [intensity, sharpness], relativeTime: 0.005, duration: hapticDuration)

            let pattern = try CHHapticPattern(events: [event], parameters: [])
            
            let player = try hapticEngine?.makeAdvancedPlayer(with: pattern)
            player?.loopEnabled = false
            //player?.completionHandler = {_ in
            //    self.currDatapoint.hapticIntensity = 0
            //}
            try player?.start(atTime: 0)
            if CHHapticEngine.capabilitiesForHardware().supportsHaptics == true {
                //currDatapoint.hapticIntensity = stimIntensity
            }

            //UNCOMMENT for debugging
            // delegate.vibrationButton.pulse() //used for testing

       } catch let error {
            NSLog("Unable to play haptic pattern because: \(error)")
       }
        
    }
    
    func makeModArr() {
        let modSet:[Int] = Array(1...modalNum)
        modalityArr = modSet
        var i = 1
        while i < numTrials{
            modalityArr.append(contentsOf: modSet)
            i += 1
        }
    }
    
    func pickModality() -> Int {
        let index = Int.random(in: 0..<modalityArr.count)
        let modal = modalityArr[index]
        modalityArr.remove(at: index)
        return modal
    }
    
    @objc func zeroRecording(){
        currDatapoint.hapticIntensity = 0
        currDatapoint.audioIntensity = 0
        currDatapoint.visualIntensity = 0
    }

}
