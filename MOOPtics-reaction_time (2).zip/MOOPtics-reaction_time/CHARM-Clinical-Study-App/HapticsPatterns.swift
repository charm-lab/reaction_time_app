//
//  HapticsPatterns.swift
//  CHARM-Clinical-Study-App
//
//  Created by Alexis Lowber on 10/5/20.
//  Copyright © 2020 Alexis Lowber. All rights reserved.
//

import Foundation
import CoreHaptics

//make 2-3 patterns under the perceivable threshold
//first is close to 10%
//evenly space the tests in terms of haptics perception level
//use 9 haptics patterns

//sensory threshold haptic patterns

//also: consider saving just the event then making a new pattern wit hmodified event parameters:https://developer.apple.com/documentation/corehaptics/updating_continuous_and_transient_haptic_parameters_in_real_time or https://exyte.com/blog/creating-haptic-feedback-with-core-haptics


let hapticPatterns = [
    [
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.1),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.2),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.3),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.4),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.5),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.6),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.7),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.8),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ],
        CHHapticPattern.Key.pattern: [
            [CHHapticPattern.Key.event: [CHHapticPattern.Key.eventType: CHHapticEvent.EventType.hapticTransient,
                  CHHapticPattern.Key.time: 0.005,
                  CHHapticPattern.Key.eventDuration: 1.0,
                 ]
            ],
            [CHHapticPattern.Key.eventParameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.9),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: 1.0)
                ]
            ]
        ]
    ]
]

