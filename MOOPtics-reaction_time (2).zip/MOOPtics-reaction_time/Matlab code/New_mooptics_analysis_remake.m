clc
close all
clear
%% Processing Data
num_subj = 24;

% Generate filenames array and analyze
filenames = generateFilename(num_subj);

% split the data up into the proper arrays
[alow,ahigh,hlow,hhigh,vlow,vhigh,...
    alowhlow,alowhhigh,ahighhlow,ahighhhigh,...
    alowvlow,alowvhigh,ahighvlow,ahighvhigh,....
    hlowvlow,hlowvhigh,hhighvlow,hhighvhigh,...
    alowhlowvlow,alowhlowvhigh,alowhhighvlow,alowhhighvhigh,...
    ahighhlowvlow,ahighhlowvhigh,ahighhhighvlow,ahighhhighvhigh] = totalAnalyze(filenames);

%plotSingle(alow,ahigh,"Auditory Stimuli Only")
%plotSingle(hlow,hhigh,"Haptic Stimuli Only")
%plotSingle(vlow,vhigh,"Visual Stimuli Only")

%% Make table 
titles = ["ID","A","H","V","Time"];
varTypes = ["double","double","double","double","double"];
dataExp = table('Size',[num_subj*26,5],'VariableTypes',varTypes,'VariableNames',titles);
% 
% % Analyze each trial
dataExp = writeToPwr(1,alow,[1,0,0],dataExp,num_subj);
dataExp = writeToPwr(2,ahigh,[2,0,0],dataExp,num_subj);
dataExp = writeToPwr(3,hlow,[0,1,0],dataExp, num_subj);
dataExp = writeToPwr(4,hhigh,[0,2,0],dataExp, num_subj);
dataExp = writeToPwr(5,vlow,[0,0,1],dataExp, num_subj);
dataExp = writeToPwr(6,vhigh,[0,0,2],dataExp, num_subj);
dataExp = writeToPwr(7,alowhlow,[1,1,0],dataExp, num_subj);
dataExp = writeToPwr(8,alowhhigh,[1,2,0],dataExp, num_subj);
dataExp = writeToPwr(9,ahighhlow,[2,1,0],dataExp, num_subj);
dataExp = writeToPwr(10,ahighhhigh,[2,2,0],dataExp, num_subj);
dataExp = writeToPwr(11,alowvlow,[1,0,1],dataExp, num_subj);
dataExp = writeToPwr(12,alowvhigh,[1,0,2],dataExp, num_subj);
dataExp = writeToPwr(13,ahighvlow,[2,0,1],dataExp, num_subj);
dataExp = writeToPwr(14,ahighvhigh,[2,0,2],dataExp, num_subj);
dataExp = writeToPwr(15,hlowvlow,[0,1,1],dataExp, num_subj);
dataExp = writeToPwr(16,hlowvhigh,[0,1,2],dataExp, num_subj);
dataExp = writeToPwr(17,hhighvlow,[0,2,1],dataExp, num_subj);
dataExp = writeToPwr(18,hhighvhigh,[0,2,2],dataExp, num_subj);
dataExp = writeToPwr(19,alowhlowvlow,[1,1,1],dataExp, num_subj);
dataExp = writeToPwr(20,alowhlowvhigh,[1,1,2],dataExp, num_subj);
dataExp = writeToPwr(21,alowhhighvlow,[1,2,1],dataExp, num_subj);
dataExp = writeToPwr(22,alowhhighvhigh,[1,2,2],dataExp, num_subj);
dataExp = writeToPwr(23,ahighhlowvlow,[2,1,1],dataExp, num_subj);
dataExp = writeToPwr(24,ahighhlowvhigh,[2,1,2],dataExp, num_subj);
dataExp = writeToPwr(25,ahighhhighvlow,[2,2,1],dataExp, num_subj);
dataExp = writeToPwr(26,ahighhhighvhigh,[2,2,2],dataExp, num_subj);

% Saving
writetable(dataExp,"tidy_data.csv");

%% Delete the bad subjects
badSubj = [13,12,7,2];      % Must be in reverse order

alow = removeSubj(alow,badSubj);
ahigh = removeSubj(ahigh,badSubj);
hlow = removeSubj(hlow,badSubj);
hhigh = removeSubj(hhigh,badSubj);
vlow = removeSubj(vlow,badSubj);
vhigh = removeSubj(vhigh,badSubj);
alowhlow = removeSubj(alowhlow,badSubj);
alowhhigh = removeSubj(alowhhigh,badSubj);
ahighhlow = removeSubj(ahighhlow,badSubj);
ahighhhigh = removeSubj(ahighhhigh,badSubj);
alowvlow = removeSubj(alowvlow,badSubj);
alowvhigh = removeSubj(alowvhigh,badSubj);
ahighvlow = removeSubj(ahighvlow,badSubj);
ahighvhigh = removeSubj(ahighvhigh,badSubj);
hlowvlow = removeSubj(hlowvlow,badSubj);
hlowvhigh = removeSubj(hlowvhigh,badSubj);
hhighvlow = removeSubj(hhighvlow,badSubj);
hhighvhigh  = removeSubj(hhighvhigh,badSubj);
alowhlowvlow = removeSubj(alowhlowvlow,badSubj);
alowhlowvhigh = removeSubj(alowhlowvhigh,badSubj);
alowhhighvlow = removeSubj(alowhhighvlow,badSubj);
alowhhighvhigh = removeSubj(alowhhighvhigh,badSubj);
ahighhlowvlow = removeSubj(ahighhlowvlow,badSubj);
ahighhlowvhigh = removeSubj(ahighhlowvhigh,badSubj);
ahighhhighvlow = removeSubj(ahighhhighvlow,badSubj);
ahighhhighvhigh  = removeSubj(ahighhhighvhigh,badSubj);
%% Plot participant fatigue
% x = (1:5);
% figure
% hold on
% for i = 1:num_subj-length(badSubj)
%     plot(x,ahigh(1:5,i))
%     plot(x,ahigh(6:10,i))
%     plot(x,ahigh(11:15,i))
% end
% hold off
%% Box plots

titleArr = ["alow","ahigh","alowvlow","alowvhigh","ahighvlow","ahighvhigh","vlow","vhigh"];
data1 = {alow,ahigh,alowvlow,alowvhigh,alowvhigh,ahighvhigh,vlow,vhigh};
makeBoxplots(data1,titleArr,"Comparing Various Stimuli")

figure()
titleArr = ["ahigh","ahighvhigh","vhigh"];
data1 = {ahigh,ahighvhigh,vhigh};
makeBoxplots(data1,titleArr,"Comparing Various Stimuli")


%% Make "Figure one"
%makeFullMultiBoxes(alow,ahigh,hlow,hhigh,vlow,vhigh,...
%     alowhlow,alowhhigh,ahighhlow,ahighhhigh,...
%     alowvlow,alowvhigh,ahighvlow,ahighvhigh,....
%     hlowvlow,hlowvhigh,hhighvlow,hhighvhigh,...
%     alowhlowvlow,alowhlowvhigh,alowhhighvlow,alowhhighvhigh,...
%     ahighhlowvlow,ahighhlowvhigh,ahighhhighvlow,ahighhhighvhigh,"Overall Data")

%% Make the remaining figures Kyle needs
close all
if true
    figure()
    makeAllStimBoxes({alowhlow,alowhhigh,ahighhlow,ahighhhigh,alowhlow,alowhhigh,ahighhlow,ahighhhigh},"test");
    allBoxes = gcf;
    exportgraphics(allBoxes,'allBoxes.jpg','Resolution',600)
end
% Make the 2-way anova graphs 
% Change this to for i = 1:1 to make it run (used a for loop to make it
% collapsible in the matlab compiler
for i = 1:1
    figure()
    arrs1 = {hlowvlow,hlowvhigh,hhighvlow,hhighvhigh};
    levels1 = [0.407,0.375,0.406,0.376];
    stds1 = [0.055,0.048,0.054,0.05];
    pvals1 = [0.000000455,0.000000228];
    makeTwoWay(arrs1,levels1,stds1,pvals1,["Haptic Level","Low Visual","High Visual","Haptic","Visual"],"Visual and Haptic")
    hv2way = gcf;
    exportgraphics(hv2way,'hv2way.jpg','Resolution',600);

    figure()
    arrs2 = {alowvlow,alowvhigh,ahighvlow,ahighvhigh};
    levels2 = [0.364,0.346,0.364,0.346];
    stds2 = [0.047,0.049,0.055,0.038];
    pvals2 = [0.0000753,0.000209];
    makeTwoWay(arrs2,levels2,stds2,pvals2,["Audio Level","Low Visual","High Visual","Audio","Visual"],"Audio and Visual")
    av2way = gcf;
    exportgraphics(av2way,'av2way.jpg','Resolution',600);

    figure()
    arrs3 = {alowhlow,alowhhigh,ahighhlow,ahighhhigh};
    levels3 = [0.377,0.371,0.382,0.367];
    stds3 = [0.045,0.056,0.054,0.047];
    pvals3 = [0.305,0.003];
    makeTwoWay(arrs3,levels3,stds3,pvals3,["Audio Level","Low Haptic","High Haptic","Audio","Haptic"],"Audio and Haptic")
    ah2way = gcf;
    exportgraphics(ah2way,'ah2way.jpg','Resolution',600)
end

% Posthoc for the two way
if true
    figure()
    arrs4 = {alow,ahigh,hlow,hhigh,vlow,vhigh};
    withinPValues = [0.008,0.0000015,0.0000206];
    % Alow-hlow,hlow-vlow,ahigh-vhigh,hhigh-vhigh,alow-vlow,ahigh-vhigh
    betweenPValues = [0.000000154,0.002,0.00000337,0.002];
    plotTWPosthoc(arrs4,withinPValues,betweenPValues,"Two Way Anova with Transformed Data")
    twoWayPostHoc = gca;
    exportgraphics(twoWayPostHoc,'twoWayPostHoc.jpg','Resolution',600)
end

%%%% Plotting and data display %%%%%%
function plotSingle(low,high,plotTitle)
    figure
    hold on

    [goodLowData, lowErrs] = cleanData(low);
    [goodHighData, highErrs] = cleanData(high);
    
    % Plot the good data
    plot(ones(length(goodLowData)),goodLowData,"bo")
    hold on
    plot(2.*ones(length(goodHighData)),goodHighData,"bo")
    plot(1,mean(goodLowData),"rx")
    plot(2,mean(goodHighData),"rx")
    %boxplot(1,goodLowData,-std(goodLowData),std(goodLowData))
    % Plot the errors
    %plot(ones(length(lowErrs)),lowErrs,"o")
    %plot(2.*ones(length(highErrs)),highErrs,"o")
    title(plotTitle)
    xlim([0,3])
    ylim([0,1.4])
    ylabel("Reaction Times (S)")
    hold off
end

% Make boxplots (takes in cell matrix of arrays, and array of titles
function makeBoxplots(arrs,titles,mainTitle)
    % turn each array into single column and then make that into an array
    arrSize = size(cell2mat(arrs(1)));
    singleArrs = [];
    grp = [];
    for i = 1:length(arrs)
        rawData = singleColumn(cell2mat(arrs(i)));
        [errorFree,~] = cleanData(rawData);
        singleArrs = [singleArrs; errorFree];
        grp = [grp;i.*ones(size(errorFree))];
    end
    
    % Plot the boxplots
    boxplot(singleArrs,grp,'Labels',titles)
    title(mainTitle)
    xlabel("Trial Name")
    ylabel("Response Time (s)")
end

% Make specialty boxplots (takes in cell matrix of arrays, and array of titles
function makeAllStimBoxes(arrs,mainTitle)
    % turn each array into single column and then make that into an array
    singleArrs1 = [];
    singleArrs2 = [];
    grp1 = [];
    grp2 = [];
    positions = [1,1.25,2,2.25];
    for i = 1:4
        rawData = singleColumn(cell2mat(arrs(i)));
        [errorFree,~] = cleanData(rawData);
        singleArrs1 = [singleArrs1; errorFree];
        grp1 = [grp1;i.*ones(size(errorFree))];
    end
    
    for i = 5:8
        rawData = singleColumn(cell2mat(arrs(i)));
        [errorFree,~] = cleanData(rawData);
        singleArrs2 = [singleArrs2; errorFree];
        grp2 = [grp2;i.*ones(size(errorFree))];
    end
    
    % Plot the boxplots
    t = tiledlayout(1,3);
    color = ['c', 'y', 'c', 'y'];
    nexttile,boxplot(singleArrs1,grp1,'Positions',positions)
    title("Low Visual Level")  
    % Change the colors and labels 
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) ])
    set(gca,'xticklabel',{'Low','High'})
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    
    % Graph the next thing
    nexttile,boxplot(singleArrs2,grp2,'Positions',positions)
    title("High Visual Level")
    %title(t,mainTitle)
    xlabel(t,"Audio Level")
    ylabel(t,"Response Time (s)")
    
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) ])
    set(gca,'xticklabel',{'Low','High'})
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    
    % Make the legend and add a title
%     hleg1 = legend(c(1:2), 'Low', 'High' );
%     [hleg,icons,plots] = legend('show');
%     title(hleg,'Haptic Level')
%     hleg.Title.Visible = 'on';
%     % the addition in height needed for the title:
%     title_hight = hleg.Position(4)/numel(plots);
%     Position([2 4]) = [hleg.Position(2)-title_hight hleg.Position(4)+title_hight];
%     % calculate new position for the elements in the legeng:
%     new_pos = fliplr(0.5/(numel(plots)+1):1/(numel(plots)+1):1);
%     hleg.Title.NodeChildren.Position = [0.5 new_pos(1) 0];
%     % set the text to the right position:
%     leg_txt = findobj(icons,'Type','Text');
%     txt_pos = cell2mat({leg_txt.Position}.');
%     txt_pos(:,2) = new_pos(2:end);
%     set(leg_txt,{'Position'},mat2cell(txt_pos,[1 1],3));
%     % set the icons to the right position:
%     leg_att = findobj(icons,'Type','Line');
%     set(leg_att,{'YData'},mat2cell(repmat(repelem(new_pos(2:end).',...
%         numel(plots)),1,2),ones(numel(plots)*2,1),2))
%     
    legend("Haptic Low", "Haptic High")
    
    % Plot the third graph
    positions = [1,1.25,2,2.25,3,3.25];
    % audio, haptic, visual (low/high order)
    levels = [0.346,0.331,0.344,0.333,0.343,0.334];
    errors = [0.04,0.043,0.042,0.041,0.043,0.04];
    nexttile;
    b = bar(positions,levels,'FaceColor','flat');
    b.CData(:,:) = [1 0 0; 1 0 0; 0 1 0; 0 1 0; 0 0.8 0.8; 0 0.8 0.8];
    hold on
    
    er = errorbar(positions,levels,errors,errors);
    er.Color = [0,0,0];
    er.LineStyle = 'none';
    
    secColor = ['r','r','g','g','b','b'];
    % Change the colors and labels 
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6))])
    set(gca,'xticklabel',{'Audio','Visual','Haptic'})
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),secColor(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    
    title("INSERT TITLE")
    
    % Do the p stars
    starGrps = {[1,1.25],[2,2.25],[3,3.25]};
    H=sigstar(starGrps,[4.07E-5,1.05E-4,7E-3]);
end

% Make 1-missing anova graphs (likely could be combined with above)
% Axis titles is x-axis and then legend
function makeTwoWay(arrs,levels,errors,pvalues,axisTitles,mainTitle)
    % turn each array into single column and then make that into an array
    singleArrs1 = [];
    grp1 = [];
    positions = [1.25,1.5,2,2.25];
    color = ['r', 'b', 'r', 'b'];

    % Plot the boxplots
    t = tiledlayout(1,2);
    nexttile;
    hold on
    
    for i = 1:length(arrs)
        rawData = singleColumn(cell2mat(arrs(i)));
        errorFree = justGood(rawData);
        grp1 = [positions(i).*ones(size(errorFree))];
        s = swarmchart(grp1,errorFree,2,color(i),'filled','MarkerFaceAlpha',0.5,'MarkerEdgeAlpha',1);%,'Positions',positions)
        s.XJitterWidth = 0.15;
    end

    hold off
    xlim([min(positions)-0.25,max(positions)+0.25])
    ylim([0.15,1.5])
    % Change the colors and labels 
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) ])
    set(gca,'xticklabel',{'Low','High'})
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    
    % Make the legend and add a title
     hleg1 = legend(c(2:3), axisTitles(2), axisTitles(3));
%     [hleg,icons,plots] = legend('show');
%     title(hleg,'Haptic Level')
%     hleg.Title.Visible = 'on';
%     % the addition in height needed for the title:
%     title_hight = hleg.Position(4)/numel(plots);
%     Position([2 4]) = [hleg.Position(2)-title_hight hleg.Position(4)+title_hight];
%     % calculate new position for the elements in the legeng:
%     new_pos = fliplr(0.5/(numel(plots)+1):1/(numel(plots)+1):1);
%     hleg.Title.NodeChildren.Position = [0.5 new_pos(1) 0];
%     % set the text to the right position:
%     leg_txt = findobj(icons,'Type','Text');
%     txt_pos = cell2mat({leg_txt.Position}.');
%     txt_pos(:,2) = new_pos(2:end);
%     set(leg_txt,{'Position'},mat2cell(txt_pos,[1 1],3));
%     % set the icons to the right position:
%     leg_att = findobj(icons,'Type','Line');
%     set(leg_att,{'YData'},mat2cell(repmat(repelem(new_pos(2:end).',...
%         numel(plots)),1,2),ones(numel(plots)*2,1),2))
     
    title(t,mainTitle)
    xlabel(axisTitles(1))
    ylabel(t,"Response Time (s)")
    
    % Plot the third graph
    positions = [0.75,1.25,2,2.5];
    % audio, haptic, visual (low/high order)
    nexttile;
    b = bar(positions,levels,'FaceColor','flat');
    b.CData(:,:) = [1 0 0; 1 0 0; 0 1 0; 0 1 0];
    xlim([min(positions)-0.5,max(positions)+0.5])
    ylim([0,0.47])
    hold on
    
    % Plot the stds
    errors = errors./sqrt(20);
    er = errorbar(positions,levels,errors,errors);
    er.Color = [0,0,0];
    er.LineStyle = 'none';
    
    secColor = ['r','r','g','g','b','b'];
    % Change the colors and labels 
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4))])
    set(gca,'xticklabel',{axisTitles(4),axisTitles(5)})
    
    % Now mark the intensities
    row1 = {'Low','High','Low','High'};
    row2 = {string(axisTitles(4)),'',axisTitles(5),''};
    labelArray = [row1; row2];
    tickLabels = strtrim(sprintf('%s\\newline%s\n', labelArray{:}));
    set(gca,'xtick',positions)
    set(gca,'xticklabel',tickLabels)
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),secColor(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    %legend(c(2), axisTitles(2), axisTitles(3));
    title("INSERT TITLE")
    
    % Do the p stars
    starGrps = {[positions(1:2)],[positions(3:4)]};
    H=sigstar(starGrps,pvalues);
end

% Make 2-way post hoc, withinPVals is the pvals within the types, betw is
% between the types. Maintain an A/H/V order
% betwPvals is of order
% Alow-hlow,hlow-vlow,ahigh-vhigh,hhigh-vhigh,alow-vlow,ahigh-vhigh
function plotTWPosthoc(arrs,withinPVals,betwPVals,mainTitle)
    % turn each array into single column and then make that into an array
    singleArrs1 = [];
    grp1 = [];
    positions = [1,1.25,2,2.25,3,3.25];
    c1 = 'r';
    c2 = 'b';
    color = [c1, c2, c1, c2, c1, c2];

    for i = 1:length(arrs)
        rawData = singleColumn(cell2mat(arrs(i)));
        [errorFree,~] = cleanData(rawData);
        grp1 = [positions(i).*ones(size(errorFree))];

        s = swarmchart(grp1,errorFree,2,color(i),'filled','MarkerFaceAlpha',0.5,'MarkerEdgeAlpha',1);%,'Positions',positions)
        s.XJitterWidth = 0.15;
        hold on
    end
    
    % Plot the boxplots

    % Change the colors and labels 
    set(gca,'xtick',[mean(positions(1:2)) mean(positions(3:4)) mean(positions(5:6))])
    set(gca,'xticklabel',{'Audio','Haptic','Visual'})
    ylim([0.2,2])
    
    h = findobj(gca,'Tag','Box');
    for j=1:length(h)
        patch(get(h(j),'XData'),get(h(j),'YData'),color(j),'FaceAlpha',.5);
    end
    
    c = get(gca, 'Children');
    
    % Make the legend and add a title
%     [hleg,icons,plots] = legend('show');
%     title(hleg,'Haptic Level')
%     hleg.Title.Visible = 'on';
%     % the addition in height needed for the title:
%     title_hight = hleg.Position(4)/numel(plots);
%     Position([2 4]) = [hleg.Position(2)-title_hight hleg.Position(4)+title_hight];
%     % calculate new position for the elements in the legeng:
%     new_pos = fliplr(0.5/(numel(plots)+1):1/(numel(plots)+1):1);
%     hleg.Title.NodeChildren.Position = [0.5 new_pos(1) 0];
%     % set the text to the right position:
%     leg_txt = findobj(icons,'Type','Text');
%     txt_pos = cell2mat({leg_txt.Position}.');
%     txt_pos(:,2) = new_pos(2:end);
%     set(leg_txt,{'Position'},mat2cell(txt_pos,[1 1],3));
%     % set the icons to the right position:
%     leg_att = findobj(icons,'Type','Line');
%     set(leg_att,{'YData'},mat2cell(repmat(repelem(new_pos(2:end).',...
%         numel(plots)),1,2),ones(numel(plots)*2,1),2))
%     
    %legend("High Level","Low Level")
    title(mainTitle)
    xlabel("Stimulus Type")
    ylabel("Response Time (s)")
    
    % Make the p-value stars
    withinStarGrps = {[1,1.25],[2,2.25],[3,3.25]};
    H=sigstar(withinStarGrps,withinPVals);
    
    % Alow-hlow,hlow-vlow,ahigh-vhigh,hhigh-vhigh,alow-vlow,ahigh-vhigh
    betwStarGrps = {[1,2],[1.25,2.25],[1,3],[1.25,3.25]};
    H=sigstar(betwStarGrps,betwPVals);

    hleg1 = legend(c(2:3), 'Low', 'High','');
end

function makeFullMultiBoxes(alow,ahigh,hlow,hhigh,vlow,vhigh,...
    alowhlow,alowhhigh,ahighhlow,ahighhhigh,...
    alowvlow,alowvhigh,ahighvlow,ahighvhigh,....
    hlowvlow,hlowvhigh,hhighvlow,hhighvhigh,...
    alowhlowvlow,alowhlowvhigh,alowhhighvlow,alowhhighvhigh,...
    ahighhlowvlow,ahighhlowvhigh,ahighhhighvlow,ahighhhighvhigh,mainTitle)
    
    noColor = 'b';
    lowColor = 'y';
    highColor = 'gr';
    
    t = tiledlayout(1,3)
    % First subplot (No visual)
    tablenone = makeBoxTable([],hlow,hhigh,alow,ahigh,...
        alowhlow,alowhhigh,ahighhlow,ahighhhigh);    
    %subplot(1,3,1)
    nexttile,plotBoxSet(tablenone)
    
    % Second subplot (Low Visual)
    tablelow = makeBoxTable(vlow,hlowvlow,hhighvlow,alowvlow,ahighvlow,...
        alowhlowvlow,alowhhighvlow,ahighhlowvlow,ahighhhighvlow);
    %subplot(1,3,2)
    nexttile,plotBoxSet(tablelow)
    
    % Third subplot (High visual)
    tablehigh = makeBoxTable(vhigh,hlowvhigh,hhighvhigh,alowvhigh,ahighvhigh,...
        alowhlowvhigh,alowhhighvhigh,ahighhlowvhigh,ahighhhighvhigh);
    %subplot(1,3,3)
    nexttile,plotBoxSet(tablehigh)
    
    sgtitle(mainTitle)
    xlabel(t,'Audio Level')
    ylabel(t,"Reaction Time")
    legend("None","Low","High")
    
    [hleg,icons,plots] = legend('show');
    title(hleg,'Haptic Level')
    hleg.Title.Visible = 'on';
    % the addition in height needed for the title:
    title_hight = hleg.Position(4)/numel(plots);
    hleg.Position([2 4]) = [hleg.Position(2)-title_hight hleg.Position(4)+title_hight];
    % calculate new position for the elements in the legeng:
    new_pos = fliplr(0.5/(numel(plots)+1):1/(numel(plots)+1):1);
    hleg.Title.NodeChildren.Position = [0.5 new_pos(1) 0];
    % set the text to the right position:
    leg_txt = findobj(icons,'Type','Text');
    txt_pos = cell2mat({leg_txt.Position}.');
    txt_pos(:,2) = new_pos(2:end);
    set(leg_txt,{'Position'},mat2cell(txt_pos,[1 1],3));
    % set the icons to the right position:
    leg_att = findobj(icons,'Type','Line');
    set(leg_att,{'YData'},mat2cell(repmat(repelem(new_pos(2:end).',...
        numel(plots)),1,2),ones(numel(plots)*2,1),2))
end

% A helper function to plot just one of the subplots
function plotBoxSet(dataTable)
    hold on
    audioOrder = {'None','Low', 'High'};
    dataTable.audio = categorical(dataTable.audio,audioOrder);
    hapticsOrder = {'None','Low','High'};
    dataTable.haptics = categorical(dataTable.haptics,hapticsOrder);
    boxchart(dataTable.audio,dataTable.allData,'GroupByColor',dataTable.haptics)
    hold off
end

% Make tables for the multi box plot
function boxTable = makeBoxTable(v,hlowv,hhighv,alowv,ahighv,alowhlowv,alowhhighv,ahighhlowv,ahighhhighv)
    haptics = [];
    audio = [];
    allData = [];
    
    % Go through each array
    [haptics, audio, allData] = makeBoxArr(ahighv,haptics,"None",audio,"High",allData);
    [haptics, audio, allData] = makeBoxArr(alowv,haptics,"None",audio,"Low",allData);
    [haptics, audio, allData] = makeBoxArr(v,haptics,"None",audio,"None",allData);
    [haptics, audio, allData] = makeBoxArr(ahighhlowv,haptics,"Low",audio,"High",allData);
    [haptics, audio, allData] = makeBoxArr(alowhlowv,haptics,"Low",audio,"Low",allData);
    [haptics, audio, allData] = makeBoxArr(hlowv,haptics,"Low",audio,"None",allData);
    [haptics, audio, allData] = makeBoxArr(ahighhhighv,haptics,"High",audio,"High",allData);
    [haptics, audio, allData] = makeBoxArr(alowhhighv,haptics,"High",audio,"Low",allData);
    [haptics, audio, allData] = makeBoxArr(hhighv,haptics,"High",audio,"None",allData);
    boxTable =  table(haptics,audio,allData);
end

% A helper function to add the 
function [hap, aud, respData] = makeBoxArr(fullArr,haptics,hapCond,audio,audCond,currData)
    hap = haptics;
    aud = audio;
    respData = currData;
    % Clean the Array;
    arr = justGood(fullArr);
    for i = 1:length(arr)
        hap = [hap;hapCond];
        aud = [aud;audCond];
        respData = [respData;arr(i)];
    end
end
%%%%% Data processing %%%%%%
% A function, given filename, stores data in proper form
function [time, but_press, stimuli] = read_data(file_name)
   data = csvread(file_name, 6, 0);
   time = data(:,1);
   but_press = data(:,4);
   stimuli = data(:,5:7);
end

% Generates an array of filenames, given number of subjects
function [filenames] = generateFilename(subj)
    filenames = strings(3,subj);
    
    % Declare the base filename
    basefile = "v_reactionTimeData";
%     
%     for i = 1:subj
%         filenames(1,i) = basefile + string(i) + ".csv";
%         filenames(2,i) = basefile + string(i) + " (1).csv";
%         filenames(3,i) = basefile + string(i) + " (2).csv";
%     end
    
    % Kyle's preferred way:
    for i = 1:subj
        filenames(1,i) = basefile + string(3*(i-1)+1) + ".csv";
        filenames(2,i) = basefile + string(3*(i-1)+2) + ".csv";
        filenames(3,i) = basefile + string(3*(i-1)+3) + ".csv";
    end
end

% A function that, given an array of filenames, outputs arrays of each
% trial with each subject's data
function [alow,ahigh,hlow,hhigh,vlow,vhigh,...
    alowhlow,alowhhigh,ahighhlow,ahighhhigh,...
    alowvlow,alowvhigh,ahighvlow,ahighvhigh,....
    hlowvlow,hlowvhigh,hhighvlow,hhighvhigh,...
    alowhlowvlow,alowhlowvhigh,alowhhighvlow,alowhhighvhigh,...
    ahighhlowvlow,ahighhlowvhigh,ahighhhighvlow,ahighhhighvhigh] = totalAnalyze(fileNames)
    
    % Initialize
    dimen = size(fileNames);
    subjects = dimen(2);
    
    alow = zeros(15,subjects);
    ahigh = zeros(15,subjects);
    hlow = zeros(15,subjects);
    hhigh = zeros(15,subjects);
    vlow = zeros(15,subjects);
    vhigh = zeros(15,subjects);
    alowhlow = zeros(15,subjects);
    alowhhigh = zeros(15,subjects);
    ahighhlow = zeros(15,subjects);
    ahighhhigh = zeros(15,subjects);
    alowvlow = zeros(15,subjects);
    alowvhigh = zeros(15,subjects);
    ahighvlow = zeros(15,subjects);
    ahighvhigh = zeros(15,subjects);
    hlowvlow = zeros(15,subjects);
    hlowvhigh = zeros(15,subjects);
    hhighvlow = zeros(15,subjects);
    hhighvhigh = zeros(15,subjects);
    alowhlowvlow = zeros(15,subjects);
    alowhlowvhigh = zeros(15,subjects);
    alowhhighvlow = zeros(15,subjects);
    alowhhighvhigh = zeros(15,subjects);
    ahighhlowvlow = zeros(15,subjects);
    ahighhlowvhigh = zeros(15,subjects);
    ahighhhighvlow = zeros(15,subjects);
    ahighhhighvhigh = zeros(15,subjects);
    
    % Analyze each file and accordingly segment the data into arrays
    for j = 1:dimen(2)
        for i = 1:dimen(1)
            file_name = fileNames(i,j);
            [rxnTime] = analyzeFile(file_name);
            
            [alow1,ahigh1,hlow1,hhigh1,vlow1,vhigh1,...
                alowhlow1,alowhhigh1,ahighhlow1,ahighhhigh1,...
                alowvlow1,alowvhigh1,ahighvlow1,ahighvhigh1,....
                hlowvlow1,hlowvhigh1,hhighvlow1,hhighvhigh1,...
                alowhlowvlow1,alowhlowvhigh1,alowhhighvlow1,alowhhighvhigh1,...
                ahighhlowvlow1,ahighhlowvhigh1,ahighhhighvlow1,ahighhhighvhigh1] = split(rxnTime);
            
            % Make anything that doesn't have 5 values have 5 values
            % (failsafe in case of app issue
            %display("alow")
            alow1 = makeFive(alow1);
            %display("ahigh")
            ahigh1 = makeFive(ahigh1);
            %display("hlow")
            hlow1 = makeFive(hlow1);
            %display("hhigh")
            hhigh1 = makeFive(hhigh1);
            %display("vlow")
            vlow1 = makeFive(vlow1);
            %display("vhigh")
            vhigh1 = makeFive(vhigh1);
            %display("alowhlow")
            alowhlow1 = makeFive(alowhlow1);
            %display("alowhhigh")
            alowhhigh1 = makeFive(alowhhigh1);
            %display("ahighhlow")
            ahighhlow1 = makeFive(ahighhlow1);
            %display("ahighhhigh")
            ahighhhigh1 = makeFive(ahighhhigh1);
            %display("alowvlow")
            alowvlow1 = makeFive(alowvlow1);
            %display("alowvhigh")
            alowvhigh1 = makeFive(alowvhigh1);
            %display("ahighvlow")
            ahighvlow1 = makeFive(ahighvlow1);
            %display("ahighvhigh")
            ahighvhigh1 = makeFive(ahighvhigh1);
            %display("hlowvlow")
            hlowvlow1 = makeFive(hlowvlow1);
            %display("hlowvhigh")
            hlowvhigh1 = makeFive(hlowvhigh1);
            %display("hhighvlow")
            hhighvlow1 = makeFive(hhighvlow1);
            %display("hhighvhigh")
            hhighvhigh1 = makeFive(hhighvhigh1);  
            %display("alowhlowvlow")
            alowhlowvlow1 = makeFive(alowhlowvlow1);
            %display("alowhlowvhigh")
            alowhlowvhigh1 = makeFive(alowhlowvhigh1);
            %display("alowhhighvlow")
            alowhhighvlow1 = makeFive(alowhhighvlow1);
            %display("alowhhighvhigh")
            alowhhighvhigh1 = makeFive(alowhhighvhigh1);
            %display("ahighhlowvlow")
            ahighhlowvlow1 = makeFive(ahighhlowvlow1);
            %display("ahighhlowvhigh")
            ahighhlowvhigh1 = makeFive(ahighhlowvhigh1);
            %display("ahighhighvlow")
            ahighhhighvlow1 = makeFive(ahighhhighvlow1);
            %display("ahighhhighvhigh")
            ahighhhighvhigh1 = makeFive(ahighhhighvhigh1);
            
            % Use a for loop to put in the values one by one
            start = 5*(i-1)+1;
            l = 1;
            for k = start:start+4
                alow(k,j) = alow1(l);
                ahigh(k,j) = ahigh1(l);
                hlow(k,j) = hlow1(l);
                hhigh(k,j) = hhigh1(l);
                vlow(k,j) = vlow1(l);
                vhigh(k,j) = vhigh1(l);
                alowhlow(k,j) = alowhlow1(l);
                alowhhigh(k,j) = alowhhigh1(l); 
                ahighhlow(k,j) = ahighhlow1(l);
                ahighhhigh(k,j) = ahighhhigh1(l);
                alowvlow(k,j) = alowvlow1(l);
                alowvhigh(k,j) = alowvhigh1(l);
                ahighvlow(k,j) = ahighvlow1(l);
                ahighvhigh(k,j) = ahighvhigh1(l);
                hlowvlow(k,j) = hlowvlow1(l);
                hlowvhigh(k,j) = hlowvhigh1(l);
                hhighvlow(k,j) = hhighvlow1(l);
                hhighvhigh(k,j) = hhighvhigh1(l);
                alowhlowvlow(k,j) = alowhlowvlow1(l);
                alowhlowvhigh(k,j) = alowhlowvhigh1(l); 
                alowhhighvlow(k,j) = alowhhighvlow1(l);
                alowhhighvhigh(k,j) = alowhhighvhigh1(l);
                ahighhlowvlow(k,j) = ahighhlowvlow1(l);
                ahighhlowvhigh(k,j) = ahighhlowvhigh1(l);
                ahighhhighvlow(k,j) = ahighhhighvlow1(l); 
                ahighhhighvhigh(k,j) = ahighhhighvhigh1(l);
                l = l+1;
            end
        end
    end
end
% Calculates catches and measures reactions of nbacks
function [rxnTimes] = analyzeFile(file_name)
   [time, but_press, stimuli] = read_data(file_name);

   num_trials = 4;
   rxnTimes = [];    % Stores reaction times
   missed = [];
   
   % start_end_times = zeros(90, 2); % matrix for testing, see if start time of current intensity happens before end time of previous
   i = 1; % indexing through elements
   k = 1; % intensity count
   gap = 2500; % this should be the correct gap time
   while i < size(stimuli,1)-gap
       while stimuli(i,1)==0 && stimuli(i,2)==0 && stimuli(i,3)==0 % find first non-zero
           i = i + 1;
           if i > size(stimuli,1) % break if i indexes past array size
               break
           end
       end
      
       if i > size(stimuli,1) % break if i indexes past array size
           break
       end
      
       start_time = time(i);
      
       b = 0; % default no response
       end_time = 0;
       resp_time = -1;
       for n = i : i+gap % find a "yes" response
           if but_press(n)==1 && time(n)-start_time < 3.0000000
               end_time = time(n);
               resp_time = end_time-start_time;
              
               if resp_time > 0    % make sure that it's not a false pos
                   b = 1; % change to yes response
                   rxnTimes = [rxnTimes; resp_time, stimuli(i,:)];
               elseif resp_time == 0
                   disp("There was a 0 vibration response time")
                   rxnTimes = [rxnTimes; 0, stimuli(i,:)];                   
                   time(i)
               end
               
               break
           end
       end
      
       if b == 0 && resp_time == -1
           missed = [missed; resp_time,stimuli(i,:)];
           rxnTimes = [rxnTimes; -1, stimuli(i,:)];
       end
           
       k = k+1;
       i = i+gap;
   end
end

% splits the data into each of the arrays
function [alow,ahigh,hlow,hhigh,vlow,vhigh,...
    alowhlow,alowhhigh,ahighhlow,ahighhhigh,...
    alowvlow,alowvhigh,ahighvlow,ahighvhigh,....
    hlowvlow,hlowvhigh,hhighvlow,hhighvhigh,...
    alowhlowvlow,alowhlowvhigh,alowhhighvlow,alowhhighvhigh,...
    ahighhlowvlow,ahighhlowvhigh,ahighhhighvlow,ahighhhighvhigh] = split(rxnTime)
    
    alow = [];
    ahigh = [];
    hlow = [];
    hhigh = [];
    vlow = [];
    vhigh = [];
    alowhlow = [];
    alowhhigh = [];
    ahighhlow = [];
    ahighhhigh = [];
    alowvlow = [];
    alowvhigh = [];
    ahighvlow = [];
    ahighvhigh = [];
    hlowvlow = [];
    hlowvhigh = [];
    hhighvlow = [];
    hhighvhigh = [];
    alowhlowvlow = [];
    alowhlowvhigh = [];
    alowhhighvlow = [];
    alowhhighvhigh = [];
    ahighhlowvlow = [];
    ahighhlowvhigh = [];
    ahighhhighvlow = [];
    ahighhhighvhigh = [];
    
    for i = 1:length(rxnTime)
        time = rxnTime(i,1);
        a = rxnTime(i,2);
        h = rxnTime(i,3);
        v = rxnTime(i,4);
        cond = [a,h,v];
        
        if cond == [2,0,0]
            alow = [alow;time];
        elseif cond == [1,0,0]
            ahigh = [ahigh;time];
        elseif cond == [0,2,0]
            hlow = [hlow;time];
        elseif cond == [0,1,0]
            hhigh = [hhigh;time];
        elseif cond == [0,0,2]
            vlow = [vlow;time];
        elseif cond == [0,0,1]
            vhigh = [vhigh;time];
        elseif cond == [2,2,0]
            alowhlow = [alowhlow;time];
        elseif cond == [2,1,0]
            alowhhigh = [alowhhigh;time];
        elseif cond == [1,2,0]
            ahighhlow = [ahighhlow;time];
        elseif cond == [1,1,0]
            ahighhhigh = [ahighhhigh;time];
        elseif cond == [0,2,2]
            hlowvlow = [hlowvlow;time];
        elseif cond == [0,2,1]
            hlowvhigh = [hlowvhigh;time];
        elseif cond == [0,1,2]
            hhighvlow = [hhighvlow;time];
        elseif cond == [0,1,1]
            hhighvhigh = [hhighvhigh;time];
        elseif cond == [2,0,2]
            alowvlow = [alowvlow;time];
        elseif cond == [2,0,1]
            alowvhigh = [alowvhigh;time];
        elseif cond == [1,0,2]
            ahighvlow = [ahighvlow;time];
        elseif cond == [1,0,1]
            ahighvhigh = [ahighvhigh;time];
        elseif cond == [2,2,2]
            alowhlowvlow = [alowhlowvlow;time];
        elseif cond == [2,2,1]
            alowhlowvhigh = [alowhlowvhigh;time];
        elseif cond == [2,1,2]
            alowhhighvlow = [alowhhighvlow;time];
        elseif cond == [2,1,1]
            alowhhighvhigh = [alowhhighvhigh;time];
        elseif cond == [1,2,2]
            ahighhlowvlow = [ahighhlowvlow;time];
        elseif cond == [1,2,1]
            ahighhlowvhigh = [ahighhlowvhigh;time];
        elseif cond == [1,1,2]
            ahighhhighvlow = [ahighhhighvlow;time];
        elseif cond == [1,1,1]
            ahighhhighvhigh = [ahighhhighvhigh;time];
        else
            display("The if statements don't cover everything")
        end
    end
end

% Makes a matrix that may be less than 5 elements and take it up to 5 
function fiveArray = makeFive(inputArr)
arrSize = max(size((inputArr)));

% Go through possibilities of input array 
if arrSize == 5
    fiveArray = inputArr;
elseif arrSize > 5
    fiveArray = inputArr(1:5);
    display("Input array into makeFive function exceeded size of 5")
else
    fiveArray = inputArr;
    display("makeFive input under size of 5")
    for i = 1:(5-arrSize)
        fiveArray = [fiveArray;-2];     % -2 marks an app error
    end
end
end

% Splits the array into good data, and then other responses
function [goodData, errors] = cleanData(array)
goodData = [];
errors = [];

for i = 1: length(array)
    if array(i) > .050 && array(i) < 1.50
        goodData = [goodData;array(i)];
    else
        errors = [errors;array(i)];
    end
end
end

function goodData = justGood(array)
goodData = [];

for i = 1: length(array)
    if array(i) > .050 && array(i) < 1.50
        goodData = [goodData;array(i)];
    end
end
end

% Turns any array into a single column
function newArr = singleColumn(oldArr)
    sizeArr = size(oldArr);
    numCol = sizeArr(2);
    
    newArr = [];
    % Go through each column and add it on
    for i = 1:numCol
        newArr = [newArr; oldArr(:,i)];
    end
end

function newArr = singleRow(oldArr)
    sizeArr = size(oldArr);
    numCol = sizeArr(2);
    
    newArr = [];
    % Go through each column and add it on
    for i = 1:numCol
        newArr = [newArr, oldArr(:,i)];
    end
end
% Returns an array of proper size of means and stds of the data
% function dataArray = pwrData(arr, numSubj)
%     % Initialize the data array (assumes 3 trials)
%     dataArray = zeros(2,3*numSubj);
%     
%     for i = 1:numSubj
%         [cleanA,~] = cleanData(arr(1:5,i));
%         start = (i-1)*3;
%         dataArray(1,start+1) = mean(cleanA);
%         dataArray(2,start+1) = std(cleanA);
%         
%         [cleanB,~] = cleanData(arr(6:10,i));
%         dataArray(1,start+2) = mean(cleanB);
%         dataArray(2,start+2) = std(cleanB);
%         
%         [cleanC,~] = cleanData(arr(11:15,i));
%         dataArray(1,start+3) = mean(cleanC);
%         dataArray(2,start+3) = std(cleanC);      
%     end
% end

% Writes to the data table
function newTable = writeToPwr(tStart,arr,trialDesc,oldTable,numSub)
    newTable = oldTable;
    for i = 1:numSub
        newStart = tStart + 26 * (i-1);
        newTable(newStart,1) = {i};
        newTable(newStart,2:4) = array2table(trialDesc);
        [cleanArr,~] = cleanData(arr(:,i));
        newTable(newStart,5) = {mean(cleanArr)};
    end
end

% Gets rid of bad subjects
function newArr = removeSubj(oldArr,badSubj)    % badSubj must be in decreasing order
    newArr = oldArr;
    for i = 1:length(badSubj)
        newArr(:,badSubj(i)) = [];
    end
end
