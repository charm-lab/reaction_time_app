clc
close all
clear
%% Processing Data
% Sitting - Kyle
file_name_1 = 'vibration_only_data_Sitting.csv';
[vib_count_VOS, raw_times_VOS, positive_hits_VOS, false_times_VOS, vib_responses_VOS, vib_resp_times_VOS] = vibration_analysis(file_name_1);
file_name_2 = 'nback_only_data_Sitting.csv';
[vib_count_NOS, raw_times_NOS, positive_hits_NOS, false_times_NOS, vib_responses_NOS, vib_resp_times_NOS] = vibration_analysis(file_name_2);
[nback_count_NOS, nback_responses_NOS, nback_false_responses_NOS, nback_resp_times_NOS] = nBackAnalysis(file_name_2);
file_name_3 = 'full_data_with_distraction_Sitting.csv';
[vib_count_DS, raw_times_DS, positive_hits_DS, false_times_DS, vib_responses_DS, vib_resp_times_DS] = vibration_analysis(file_name_3);
[nback_count_DS, nback_responses_DS, nback_false_responses_DS, nback_resp_times_DS] = nBackAnalysis(file_name_3);
file_name_4 = 'full_data_with_distraction_Walking.csv';
[vib_count_DW, raw_times_DW, positive_hits_DW, false_times_DW, vib_responses_DW,vib_resp_times_DW] = vibration_analysis(file_name_4);
[nback_count_DW, nback_responses_DW, nback_false_responses_DW, nback_resp_times_DW] = nBackAnalysis(file_name_4);
file_name_5 = 'vibration_only_data_Walking.csv';
[vib_count_VOW, raw_times_5, positive_hits_VOW, false_times_VOW, vib_responses_VOW,vib_resp_times_VOW] = vibration_analysis(file_name_5);
[nback_count_VOW, nback_responses_VOW, nback_false_responses_VOW, nback_resp_times_VOW] = nBackAnalysis(file_name_5);
file_name_6 = 'nback_only_data_Walking.csv';
[vib_count_NOW, raw_times_NOW, positive_hits_NOW, false_times_NOW, vib_responses_NOW,vib_resp_times_NOW] = vibration_analysis(file_name_6);
[nback_count_NOW, nback_responses_NOW, nback_false_responses_NOW, nback_resp_times_NOW] = nBackAnalysis(file_name_6);
%% Graph - SITTING
figure
% VO
vo_avg = vib_count_VOS(:,2);
x_data_1 = vib_count_VOS(:,1); % intensity
y_data_1 = vo_avg(:,1)./10; % avg between kyle and cara
% y_data_1 = vib_count_1(:,2)./10; % response proportion
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_1, y_data_1, ones(size(y_data_1)));
plot(x_data_1,y_data_1, 'color', 'b', 'LineStyle',"-","marker","o")
hold on
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "b")
% plot(x_data_1, y_data_1, 'b', "Marker", "o")
std_avg_1 = std(transpose([vib_count_VOS(:,2)/10]));
% NB
nb_avg = vib_count_NOS(:,2);
x_data_2 = vib_count_NOS(:,1); % intensity
y_data_2 = nb_avg(:,1)./10; % avg between kyle and cara
% y_data_2 = vib_count_2(:,2)./10; % response proportion
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_2, y_data_2, ones(size(y_data_2)));
plot(x_data_2,y_data_2, 'color', 'r', 'LineStyle',"-","marker","o")
% plot(x_data_2, y_data_2, 'r', 'Marker', 'o')
std_avg_2 = std(transpose([vib_count_NOS(:,2)/10 ]));
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "r")
% walking_avg = vib_count_3(:,2);
% x_data_3 = vib_count_3(:,1); % intensity
% y_data_3 = walking_avg(:,1)./10; % avg between kyle and cara
% [coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_3, y_data_3, ones(size(y_data_3)));
% plot(x_data_3,y_data_3, 'color', 'magenta', 'LineStyle',"-","marker","o")
% plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "magenta")
%
% walking_dis_avg = vib_count_4(:,2);
% x_data_4 = vib_count_4(:,1); % intensity
% y_data_4 = walking_dis_avg(:,1)./10; % avg between kyle and cara
% [coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_4, y_data_4, ones(size(y_data_4)));
% plot(x_data_4,y_data_4, 'color', 'black', 'LineStyle',"-","marker","o")
% plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "black")
%title('Baseline for Two Different Subjects (Sitting)')
%title('Nback vs. No Distraction Psychometric Curve (Sitting)')
set(gca,'FontSize',14);
legend('Sitting Data', 'Sitting Curve','Walking Data',...
   'Walking Curve', "Location", "southeast","FontSize", 14);
%legend('Subject 1 - Data', 'Subject 1 - Curve', 'Subject 1 - Data w/ Distraction','Subject 1 - Curve w/ Distraction',  ...
%   "Location", "southeast","FontSize", 14)
xlabel('Vibration Intensity',"Fontsize",14)
ylabel('Vibrations Recognized (Fraction)',"Fontsize",14)
hold off
%% Graph the nback response time data
nback_resp_times_moving = graphMovingAvg(nback_resp_times_NOS(:,1),nback_resp_times_NOS(:,2),...
   'nBack Response Times','Response Times');
% Plot the responses and a moving average
nback_responses_moving = graphMovingAvg(nback_responses_NOS(:,1),nback_responses_NOS(:,2),...
   'Correct nBack Responses', 'Correct Responses');
% Plot the moving averages over eachother
figure
yyaxis left
plot(nback_resp_times_NOS(:,1),nback_resp_times_moving,'color','b','Linestyle','--')
ylabel('Response time (s)',"Fontsize",14)
ylim([0,max(nback_resp_times_moving)*1.2])
set(gca,'Ydir','reverse')
hold on
yyaxis right
plot(nback_responses_NOS(:,1),nback_responses_moving,'color','r','Linestyle','--')
ylim([0,max(nback_responses_moving)*1.2])
grid on
legend('Response times', 'Response correctness', "Location", "southeast","FontSize", 14)
title('Moving Averages of Correctness and Response Times')
set(gca,'FontSize',14);
xlabel('Time (s)',"Fontsize",14)
ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
hold off
%% Nback - correct vs. incorrect (sitting)
% Plot the responses and a moving average
nback_false_responses_moving = graphMovingAvg(nback_false_responses_NOS(:,1),nback_false_responses_NOS(:,2),...
   'Incorrect nBack Responses', 'Incorrect Responses');
% Plot the moving averages over eachother
figure
hold on
grid on
plot(nback_responses_NOS(:,1),nback_responses_moving,'color','b','Linestyle','--')
scatter(nback_responses_NOS(:,1),nback_responses_NOS(:,2), 'b')
ylim([0,max(nback_responses_moving)*1.2])
set(gca)
plot(nback_false_responses_NOS(:,1),nback_false_responses_moving,'color','r','Linestyle','--')
scatter(nback_false_responses_NOS(:,1),nback_false_responses_NOS(:,2),'r', 'x')
legend('Correct moving avg','Correct responses','Incorrect moving avg', 'Incorrect responses', "Location", "southeast","FontSize", 14)
title('Correct vs. Incorrect Responses')
set(gca,'FontSize',14);
xlabel('Time (s)',"Fontsize",14)
ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
hold off
%% Nback only vs. distraction (sitting)
% Plot the responses and a moving average
full_sitting_responses_moving = graphMovingAvg(nback_responses_DS(:,1),nback_responses_DS(:,2),...
   'Correct nBack (with distractions) Responses', 'Correct Responses');
[nback_responses_moving,full_sitting_responses_moving] = graphTwoMovingAvg(nback_responses_NOS,nback_responses_DS, ...
   'Nback Shapes Recognized (Fraction)','Nback only correct responses','Nback with distraction correct responses');
%% Graph the vibration data response times
%vibRespTimesLabels = ['Baseline Data','Baseline Moving Average','With nBack Data','With nBack Moving Average'];
vibRespTimesLabels = {'Baseline Moving Average','With nBack Moving Average'};
%[baseline_RT_ma, vib_w_nback_RT_ma] = graphTwoMovingAvg(vib_resp_times_1,vib_resp_times_2,...
%   'Response Time to Vibrations With and Without nBack',vibRespTimesLabels);
vibResponsesLabels = {'Baseline Moving Average','With nBack Moving Average'};
%[baseline_responses_ma, vib_w_nback_responses_ma] = graphTwoMovingAvg(vib_responses_1,vib_responses_2,...
%   'Response Correctness With and Without nBack ',vibResponsesLabels);
%graphRTHist(raw_times_1,'Responses for Each Vibration Intensity')
%% Graph combined data
% Make a histogram of vibration response times vs. nback response times
histsLabels = {'Vibration Response Times','nBack Response Times'};
%graphTwoHists(vib_resp_times_2(:,2),nback_resp_times(:,2),...
%   'Histogram of Vibration and nBack Response Times',histsLabels);
% Make a histogram comparing the vibration response times between baseline
% and nback
histsLabels = {'Baseline','With nBack'};
% graphTwoHists(vib_resp_times_1(:,2),vib_resp_times_2(:,2),...
%    'Histogram of Vibration and nBack Response Times',histsLabels);
%% 4x1 subplot of histograms - vibration
histSubplot(vib_resp_times_VOS,vib_resp_times_DS,vib_resp_times_VOW,vib_resp_times_DW, 'VOS','DS','VOW','DW')
%% 4x1 subplot of histograms - nback
histSubplot(nback_resp_times_NOS,nback_resp_times_DS,nback_resp_times_NOW,nback_resp_times_DW, 'NOS','DS','NOW','DW')
%% 9-stack histogram
nineStackHist(vib_resp_times_VOS,'VOS Vibration Intensity and Response Time Distribution')
%% Mean and STD for response times of each vibration intensity
meanStd(vib_resp_times_VOS,'VOS Vibration Intensity and Response Time Mean & Standard Deviation')
%% Functions
% A function that calls all other functions to analyze vibration data
function [vib_count, raw_times, positive_hits, false_times,vib_responses,vib_resp_times] = vibration_analysis(file_name)
   % Read the file
   [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name);
   % analyze the data
   [vib_count, raw_times, positive_hits,vib_responses,vib_resp_times] = count_vibrations(time, vib_int, vib_but);
   all_hits_time = all_button_hits(time, vib_but);
  
   % Find the time that the false hits occurred
   false_times = setdiff(all_hits_time, positive_hits);
end
% A function that calls other fucntions to analyze nback data
function [nback_count, nback_responses, nback_false_responses, nback_resp_times] = nBackAnalysis(file_name)
   [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name);
   [nback_count, nback_responses, nback_false_responses, nback_resp_times] = count_nback(time, nback_shapes, nback_but)
end
% A function, given filename, stores data in proper form
function [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name)
   data = csvread(file_name, 5, 0);
   time = data(:,1);
   nback_shapes = data(:,2);
   nback_but = data(:,3);
   vib_int = data(:,4);
   vib_but = data(:,5);
end
% A function, given the app data, that calculates the intensities caught
function [vib_count,raw_vib_times,hit_times,vib_responses,vib_resp_times] = count_vibrations(time, vib_int, vib_but)
   vibrations = [0.1; 0.125; 0.15; 0.175; 0.2; 0.225; 0.25; 0.275; 0.3];
   vib_count = zeros(9,2);
   vib_count(:,1) = vibrations;
   num_trials = 10;
   raw_vib_times = zeros(9,num_trials+1);  %for response times
   raw_vib_times(:,1) = vibrations;
   raw_vib_times(:,2:end) = -1;    % initialize the matrix with something that won't be in the data
   hit_times = [];     % to store the time at which the button is hit
   vib_responses = []; % stores whether the user gets a vibration or not
   vib_resp_times = [];    % Stores response times with each time
  
   % start_end_times = zeros(90, 2); % matrix for testing, see if start time of current intensity happens before end time of previous
   i = 1; % indexing through elements
   k = 1; % intensity count
   gap = 3005; % this should be the correct gap time
   while i < size(vib_int,1)-gap
       while vib_int(i)==0 % find first non-zero
           i = i + 1;
           if i > size(vib_int,1) % break if i indexes past array size
               break
           end
       end
      
       if i > size(vib_int,1) % break if i indexes past array size
           break
       end
      
       a = vib_int(i); % get intensity
       start_time = time(i);
      
       b = 0; % default no response
       end_time = 0;
       resp_time = 0;
       for n = i : i+gap % find a "yes" response
           if vib_but(n)==1 && time(n)-start_time < 3.000000
               end_time = time(n);
               hit_times = [hit_times, time(n)];   % append the hit time
               resp_time = end_time-start_time;
              
               if resp_time > 0    % make sure that it's not a false pos
                   b = 1; % change to yes response
                   vib_resp_times = [vib_resp_times; a, start_time, resp_time];
               else
                   disp("There was a 0 vibration response time")
               end
              
               break
           end
       end
      
       [row,~] = find(vib_count(:,1)==a); % update matrix
       vib_count(row,2) = vib_count(row,2) + b; % yes count
       % vib_count(row,3) = vib_count(row,3) + 1; % intensity count
      
       %find the next empty column in the row
       if b == 1
           h = 1;
           while raw_vib_times(row,h) ~= -1 %&& h <= size(raw_times(1,:))
               h = h + 1;
           end
           raw_vib_times(row,h) = resp_time; % response times
       end
      
       vib_responses = [vib_responses; start_time, b];
      
       k = k+1;
       i = i+gap;
   end
   % disp(vib_count)
   %disp(hit_times)
end
% Calculates catches and measures reactions of nbacks
function [nback_count, nback_responses, nback_false_responses, nback_resp_times] = count_nback(time, nback_int, nback_but)
   gap = 2800;     % just less than 3 seconds
   shapes = [0];
   nback_count = 0;
   nback_responses = [];
   nback_false_responses = [];
   nback_resp_times = [];
  
   i = 1; % indexing through elements
   k = 1; % intensity count
   while i < size(nback_int,1)
       start_time = time(i);
       end_time = 0;
       resp_time = 0;
       b = 0;   %default no response
      
       while nback_int(i)==0 % find first non-zero
           i = i + 1;
           if i > size(nback_int,1) % break if i indexes past array size
               break
           end
       end
      
       if i > size(nback_int,1) % break if i indexes past array size
           break
       end       
       curr_shape = nback_int(i);
      
       if curr_shape == shapes(end) % test for n back
          nback_count = nback_count + 1;
          start_time = time(i);
          for n = i : i+gap % find a "yes" response
               if n > size(nback_int,1) % break if i indexes past array size
                   break
               end
               if nback_but(n) == 1
                   end_time = time(n);
                   resp_time = end_time - start_time;
                   if resp_time > 0
                       b = 1;
                       nback_resp_times = [nback_resp_times; curr_shape, start_time, resp_time];
                   else
                       disp("There was a 0 response time nback hit")
                   end
                   break
               end
          end
          nback_responses = [nback_responses; start_time, b];
       end
      
       if curr_shape ~= shapes(end)
          start_time = time(i);
          for n = i : i+gap % find a "yes" response
               if n > size(nback_int,1) % break if i indexes past array size
                   break
               end
               if nback_but(n) == 1
                   end_time = time(n);
                   resp_time = end_time - start_time;
                   if resp_time > 0
                       b = 1;
                   else
                       disp("There was a 0 response time nback hit")
                   end
                   break
               end
          end
           nback_false_responses = [nback_false_responses; start_time, b];
       end
      
       shapes = [shapes, curr_shape];
       k = k+1;
       i = i+gap;
   end
end
% Finds the total number of times the button was pressed and when it was pressed
function all_hits = all_button_hits(time, hit_data)
   all_hits = [];
   i = 0;
  
   % Go through looking for 1's
   while i < length(hit_data)
       if i > 1        % no error if they hit the button from the start
           if hit_data(i) == 1 && hit_data(i-1) == 0
               all_hits = [all_hits,time(i)];
           end
       end
       i = i+1;
   end
end
%% Graph functions
% Graphs moving average with data
function [moving_avg] = graphMovingAvg(x_data,y_data,graphTitle,dataLabel)
   figure
   moving_avg = movmean(y_data,7);
   plot(x_data,y_data,'color','r','Linestyle','None','Marker','o')
   hold on
   plot(x_data,moving_avg,'color','b','Linestyle','--')
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabel, 'Moving Average', "Location", "southeast","FontSize", 14)
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
   hold off
end
% Graphs two moving averages with data
function [moving_avg1,moving_avg2] = graphTwoMovingAvg(data1,data2,graphTitle,dataLabel1, dataLabel2)
   figure
   moving_avg1 = movmean(data1(:,2),7);
   %plot(data1(:,1),data1(:,2),'color','r','Linestyle','None','Marker','o')
   hold on
   grid on
   plot(data1(:,1),moving_avg1,'color','r','Linestyle','--')
   ylim([0,max(moving_avg1)*1.2])
   set(gca)
  
   moving_avg2 = movmean(data2(:,2),7);
   %plot(data2(:,1),data2(:,2),'color','b','Linestyle','None','Marker','o')
   plot(data2(:,1),moving_avg2,'color','b','Linestyle','--')
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabel1, dataLabel2, "Location", "southeast","FontSize", 14)
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
   hold off
  
end
%Graphs one histogram
function graphRTHist(data,graphTitle,bins)
   edges = linspace(0,max(data(1,:)),bins);
   figure
   dataLabels = {};
   hold on
   for i = 1 : size(data(:,1))
       real_data = [];
       for k = 2 : size(data(i,[2,end]))
           if data(i,k) > 0
               real_data = [real_data, data(i,k)];
           end
       end
       histogram(real_data)%,'BinEdges',edges)
       dataLabels = {dataLabels, int2str(data(i,1))};
   end
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabels, "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
% Graphs two overlapping hisograms
function graphTwoHists(data1,data2,graphTitle,dataLabels)
   bins = 9;
   edges = linspace(0,max(data1),bins);
   figure
   histogram(data1,'BinEdges',edges)%,'BinCounts',bins)
   hold on
   histogram(data2,'BinEdges',edges)%,'BinCounts',bins)
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabels, "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
function histSubplot(data1,data2,data3,data4, title1,title2,title3,title4)
   min_edge = min([min(data1(:,3)), min(data2(:,3)), min(data3(:,3)), min(data4(:,3))]);
   max_edge = max([max(data1(:,3)), max(data2(:,3)), max(data3(:,3)), max(data4(:,3))]);
   edges = [min_edge:0.01:max_edge];
   max_y = 5;
  
   figure
   % vibration only sitting
   subplot(4,1,1)
   histogram(data1(:,3),edges)
   ylim([0, max_y]);
   title(title1)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration only walking
   subplot(4,1,2)
   histogram(data2(:,3),edges)
   ylim([0, max_y]);
   title(title2)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,3)
   histogram(data3(:,3),edges)
   ylim([0, max_y]);
   title(title3)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,4)
   histogram(data4(:,3),edges)
   ylim([0, max_y]); 
   title(title4)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
end
function nineStackHist(data,titleLabel)
   a = floor(min(data(:,3))/.1)*.1;
   b = ceil(max(data(:,3))/.1)*.1;
   bin_size = 0.05;
   bins = (b-a)/bin_size;
   matrix = zeros(bins,9);
  
   i = 1;
   while i < (size(data,1)+1)
       if data(i,1) == 0.1
           matrix(bucket(data(i,3),a,bins,bin_size),1) = matrix(bucket(data(i,3),a,bins,bin_size),1)+1;
       elseif data(i,1) == 0.125
           matrix(bucket(data(i,3),a,bins,bin_size),2) = matrix(bucket(data(i,3),a,bins,bin_size),2)+1;   
       elseif data(i,1) == 0.15
           matrix(bucket(data(i,3),a,bins,bin_size),3) = matrix(bucket(data(i,3),a,bins,bin_size),3)+1;   
       elseif data(i,1) == 0.175
           matrix(bucket(data(i,3),a,bins,bin_size),4) = matrix(bucket(data(i,3),a,bins,bin_size),4)+1;   
       elseif data(i,1) == 0.2
           matrix(bucket(data(i,3),a,bins,bin_size),5) = matrix(bucket(data(i,3),a,bins,bin_size),5)+1;   
       elseif data(i,1) == 0.225
           matrix(bucket(data(i,3),a,bins,bin_size),6) =  matrix(bucket(data(i,3),a,bins,bin_size),6)+1;  
       elseif data(i,1) == 0.25
           matrix(bucket(data(i,3),a,bins,bin_size),7) = matrix(bucket(data(i,3),a,bins,bin_size),7)+1; 
       elseif data(i,1) == 0.275
           matrix(bucket(data(i,3),a,bins,bin_size),8) = matrix(bucket(data(i,3),a,bins,bin_size),8)+1;  
       elseif data(i,1) == 0.3
           matrix(bucket(data(i,3),a,bins,bin_size),9) = matrix(bucket(data(i,3),a,bins,bin_size),9)+1;  
       end
       i = i+1;
   end
  
   figure
   x = {}; low = a;
   for i = 1 : bins
       x{i} = [num2str(low),'-',num2str(low+bin_size)];
       low = low+bin_size;
   end
   categories = categorical(x);
   bar(categories,matrix,'stacked')
   set(gca,'FontSize',14);
   title(titleLabel)
   legend("0.1","0.125","0.15","1.75","0.2","0.225","0.25","0.275","0.3", "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
function row = bucket(resp_time,min,bins,bin_size)
   row = 0;
   for i = 1 : bins
       if resp_time > min && resp_time < min+bin_size
           row = i;
           break
       end
       min = min+bin_size;
   end
end
function meanStd(matrix,titleLabel)
   v1 = [];
   v2 = [];
   v3 = [];
   v4 = [];
   v5 = [];
   v6 = [];
   v7 = [];
   v8 = [];
   v9 = [];
  
   i = 1;
   while i < (size(matrix,1)+1)
       if matrix(i,1) == 0.1
           v1(end+1) = matrix(i,3);
       elseif matrix(i,1) == 0.125
           v2(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.15
           v3(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.175
           v4(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.2
           v5(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.225
           v6(end+1) = matrix(i,3);  
       elseif matrix(i,1) == 0.25
           v7(end+1) = matrix(i,3); 
       elseif matrix(i,1) == 0.275
           v8(end+1) = matrix(i,3);  
       elseif matrix(i,1) == 0.3
           v9(end+1) = matrix(i,3);  
       end
       i = i+1;
   end
  
   figure
   x = [0.1,0.125,0.15,0.175,0.2,0.225,0.25,0.275,0.3];
   y = [mean(v1),mean(v2),mean(v3),mean(v4),mean(v5),mean(v6),mean(v7),mean(v8),mean(v9)];
   err = [std(v1),std(v2),std(v3),std(v4),std(v5),std(v6),std(v7),std(v8),std(v9)];
   errorbar(x,y,err)
   set(gca,'FontSize',14);
   title(titleLabel)
   legend("0.1","0.125","0.15","1.75","0.2","0.225","0.25","0.275","0.3", "Location", "northeast","FontSize", 14)
   xlabel('Vibration Intensity',"Fontsize",14)
   ylabel('Response Time (s)',"Fontsize",14)
  
   figure
   col = {'0.1','0.125','0.15','0.175','0.2','0.225','0.25','0.275','0.3'};
   row = {'Mean','Standard Deviation'};
   data = {mean(v1) mean(v2) mean(v3) mean(v4) mean(v5) mean(v6) mean(v7) mean(v8) mean(v9);
           std(v1) std(v2) std(v3) std(v4) std(v5) std(v6) std(v7) std(v8) std(v9)};
   uitable('columnname',col,'rowname',row,'data',data,'position',[20 20 800 70])
end
% Psychometric graph function
function [coeffs, curve, threshold] = ...
  FitPsycheCurveLogit(xAxis, yData, weights, targets)
   % Transpose if necessary
   if size(xAxis,1)<size(xAxis,2)
      xAxis=xAxis';
   end
   if size(yData,1)<size(yData,2)
      yData=yData';
   end
   if size(weights,1)<size(weights,2)
      weights=weights';
   end
   % Check range of data
   if min(yData)<0 || max(yData)>1
       % Attempt to normalise data to range 0 to 1
      yData = yData/(mean([min(yData), max(yData)])*2);
   end
   % Perform fit
   coeffs = glmfit(xAxis, [yData, weights], 'binomial','link','logit');
   % Create a new xAxis with higher resolution
   fineX = linspace(min(xAxis),max(xAxis),numel(xAxis)*50);
   % Generate curve from fit
   curve = glmval(coeffs, fineX, 'logit');
   curve = [fineX', curve];     
   % If targets (y) supplied, find threshold (x)
   if nargin==4
   else
      targets = [0.25, 0.50, 0.75];
   end
   threshold = (log(targets./(1-targets))-coeffs(1))/coeffs(2);
end