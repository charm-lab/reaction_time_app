clc
close all
clear
%% Processing Data
%{
file_name_1a = 'VOS_Joel.csv';
[vib_count_VOSa, raw_times_VOSa, positive_hits_VOSa, false_times_VOSa, vib_responses_VOSa, vib_resp_times_VOSa] = vibration_analysis(file_name_1a);
file_name_2a = 'NOS_Joel.csv';
[vib_count_NOSa, raw_times_NOSa, positive_hits_NOSa, false_times_NOSa, vib_responses_NOSa, vib_resp_times_NOSa] = vibration_analysis(file_name_2a);
[nback_count_NOSa, nback_responses_NOSa, nback_false_responses_NOSa, nback_resp_times_NOSa] = nBackAnalysis(file_name_2a);
file_name_3a = 'DS_Joel.csv';
[vib_count_DSa, raw_times_DSa, positive_hits_DSa, false_times_DSa, vib_responses_DSa, vib_resp_times_DSa] = vibration_analysis(file_name_3a);
[nback_count_DSa, nback_responses_DSa, nback_false_responses_DSa, nback_resp_times_DSa] = nBackAnalysis(file_name_3a);
file_name_4a = 'DW_Joel.csv';
[vib_count_DWa, raw_times_DWa, positive_hits_DWa, false_times_DWa, vib_responses_DWa, vib_resp_times_DWa] = vibration_analysis(file_name_4a);
[nback_count_DWa, nback_responses_DWa, nback_false_responses_DWa, nback_resp_times_DWa] = nBackAnalysis(file_name_4a);
file_name_5a = 'VOW_Joel.csv';
[vib_count_VOWa, raw_times_VOWa, positive_hits_VOWa, false_times_VOWa, vib_responses_VOWa, vib_resp_times_VOWa] = vibration_analysis(file_name_5a);
[nback_count_VOWa, nback_responses_VOWa, nback_false_responses_VOWa, nback_resp_times_VOWa] = nBackAnalysis(file_name_5a);
file_name_6a = 'NOW_Joel.csv';
[vib_count_NOWa, raw_times_NOaW, positive_hits_NOWa, false_times_NOWa, vib_responses_NOWa, vib_resp_times_NOWa] = vibration_analysis(file_name_6a);
[nback_count_NOWa, nback_responses_NOWa, nback_false_responses_NOWa, nback_resp_times_NOWa] = nBackAnalysis(file_name_6a);
file_name_1b = 'VOS_Steven.csv';
[vib_count_VOSb, raw_times_VOSb, positive_hits_VOSb, false_times_VOSb, vib_responses_VOSb, vib_resp_times_VOSb] = vibration_analysis(file_name_1b);
file_name_2b = 'NOS_Steven.csv';
[vib_count_NOSb, raw_times_NOSb, positive_hits_NOSb, false_times_NOSb, vib_responses_NOSb, vib_resp_times_NOSb] = vibration_analysis(file_name_2b);
[nback_count_NOSb, nback_responses_NOSb, nback_false_responses_NOSb, nback_resp_times_NOSb] = nBackAnalysis(file_name_2b);
file_name_3b = 'DS_Steven.csv';
[vib_count_DSb, raw_times_DSb, positive_hits_DSb, false_times_DSb, vib_responses_DSb, vib_resp_times_DSb] = vibration_analysis(file_name_3b);
[nback_count_DSb, nback_responses_DSb, nback_false_responses_DSb, nback_resp_times_DSb] = nBackAnalysis(file_name_3b);
file_name_4b = 'DW_Steven.csv';
[vib_count_DWb, raw_times_DWb, positive_hits_DWb, false_times_DWb, vib_responses_DWb, vib_resp_times_DWb] = vibration_analysis(file_name_4b);
[nback_count_DWb, nback_responses_DWb, nback_false_responses_DWb, nback_resp_times_DWb] = nBackAnalysis(file_name_4b);
file_name_5b = 'VOW_Steven.csv';
[vib_count_VOWb, raw_times_VOWb, positive_hits_VOWb, false_times_VOWb, vib_responses_VOWb, vib_resp_times_VOWb] = vibration_analysis(file_name_5b);
[nback_count_VOWb, nback_responses_VOWb, nback_false_responses_VOWb, nback_resp_times_VOWb] = nBackAnalysis(file_name_5b);
file_name_6b = 'NOW_Steven.csv';
[vib_count_NOWb, raw_times_NOWb, positive_hits_NOWb, false_times_NOWb, vib_responses_NOWb, vib_resp_times_NOWb] = vibration_analysis(file_name_6b);
[nback_count_NOWb, nback_responses_NOWb, nback_false_responses_NOWb, nback_resp_times_NOWb] = nBackAnalysis(file_name_6b);
file_name_1c = 'VOS_Kyle.csv';
[vib_count_VOS, raw_times_VOS, positive_hits_VOS, false_times_VOS, vib_responses_VOS, vib_resp_times_VOS] = vibration_analysis(file_name_1c);
file_name_2c = 'NOS_Kyle.csv';
[vib_count_NOS, raw_times_NOS, positive_hits_NOS, false_times_NOS, vib_responses_NOS, vib_resp_times_NOS] = vibration_analysis(file_name_2c);
[nback_count_NOS, nback_responses_NOS, nback_false_responses_NOS, nback_resp_times_NOS] = nBackAnalysis(file_name_2c);
file_name_3c = 'DS_Kyle.csv';
[vib_count_DS, raw_times_DS, positive_hits_DS, false_times_DS, vib_responses_DS, vib_resp_times_DS] = vibration_analysis(file_name_3c);
[nback_count_DS, nback_responses_DS, nback_false_responses_DS, nback_resp_times_DS] = nBackAnalysis(file_name_3c);
file_name_4c = 'DW_Kyle.csv';
[vib_count_DW, raw_times_DW, positive_hits_DW, false_times_DW, vib_responses_DW,vib_resp_times_DW] = vibration_analysis(file_name_4c);
[nback_count_DW, nback_responses_DW, nback_false_responses_DW, nback_resp_times_DW] = nBackAnalysis(file_name_4c);
file_name_5c = 'VOW_Kyle.csv';
[vib_count_VOW, raw_times_VOW, positive_hits_VOW, false_times_VOW, vib_responses_VOW,vib_resp_times_VOW] = vibration_analysis(file_name_5c);
[nback_count_VOW, nback_responses_VOW, nback_false_responses_VOW, nback_resp_times_VOW] = nBackAnalysis(file_name_5c);
file_name_6c = 'NOW_Steven.csv';
[vib_count_NOW, raw_times_NOW, positive_hits_NOW, false_times_NOW, vib_responses_NOW,vib_resp_times_NOW] = vibration_analysis(file_name_6c);
[nback_count_NOW, nback_responses_NOW, nback_false_responses_NOW, nback_resp_times_NOW] = nBackAnalysis(file_name_6c);
file_name_1d = 'VOS_1.csv';
[vib_count_VOSd, raw_times_VOSd, positive_hits_VOSd, false_times_VOSd, vib_responses_VOSd, vib_resp_times_VOSd] = vibration_analysis(file_name_1d);
file_name_2d = 'NOS_1.csv';
[vib_count_NOSd, raw_times_NOSd, positive_hits_NOSd, false_times_NOSd, vib_responses_NOSd, vib_resp_times_NOSd] = vibration_analysis(file_name_2d);
[nback_count_NOSd, nback_responses_NOSd, nback_false_responses_NOSd, nback_resp_times_NOSd] = nBackAnalysis(file_name_2d);
file_name_3d = 'DS_1.csv';
[vib_count_DSd, raw_times_DSd, positive_hits_DSd, false_times_DSd, vib_responses_DSd, vib_resp_times_DSd] = vibration_analysis(file_name_3d);
[nback_count_DSd, nback_responses_DSd, nback_false_responses_DSd, nback_resp_times_DSd] = nBackAnalysis(file_name_3d);
file_name_4d = 'DW_1.csv';
[vib_count_DWd, raw_times_DWd, positive_hits_DWd, false_times_DWd, vib_responses_DWd,vib_resp_times_DWd] = vibration_analysis(file_name_4d);
[nback_count_DWd, nback_responses_DWd, nback_false_responses_DWd, nback_resp_times_DWd] = nBackAnalysis(file_name_4d);
file_name_5d = 'VOW_1.csv';
[vib_count_VOWd, raw_times_VOWd, positive_hits_VOWd, false_times_VOWd, vib_responses_VOWd,vib_resp_times_VOWd] = vibration_analysis(file_name_5d);
[nback_count_VOWd, nback_responses_VOWd, nback_false_responses_VOWd, nback_resp_times_VOWd] = nBackAnalysis(file_name_5d);
file_name_6d = 'NOW_Steven.csv';
[vib_count_NOWd, raw_times_NOWd, positive_hits_NOWd, false_times_NOWd, vib_responses_NOWd,vib_resp_times_NOWd] = vibration_analysis(file_name_6d);
[nback_count_NOWd, nback_responses_NOWd, nback_false_responses_NOWd, nback_resp_times_NOWd] = nBackAnalysis(file_name_6d);
file_name_1e = 'VOS_2.csv';
[vib_count_VOSe, raw_times_VOSe, positive_hits_VOSe, false_times_VOSe, vib_responses_VOSe, vib_resp_times_VOSe] = vibration_analysis(file_name_1e);
file_name_2e = 'NOS_2.csv';
[vib_count_NOSe, raw_times_NOSe, positive_hits_NOSe, false_times_NOSe, vib_responses_NOSe, vib_resp_times_NOSe] = vibration_analysis(file_name_2e);
[nback_count_NOSe, nback_responses_NOSe, nback_false_responses_NOSe, nback_resp_times_NOSe] = nBackAnalysis(file_name_2e);
file_name_3e = 'DS_2.csv';
[vib_count_DSe, raw_times_DSe, positive_hits_DSe, false_times_DSe, vib_responses_DSe, vib_resp_times_DSe] = vibration_analysis(file_name_3e);
[nback_count_DSe, nback_responses_DSe, nback_false_responses_DSe, nback_resp_times_DSe] = nBackAnalysis(file_name_3e);
file_name_4e = 'DW_2.csv';
[vib_count_DWe, raw_times_DWe, positive_hits_DWe, false_times_DWe, vib_responses_DWe,vib_resp_times_DWe] = vibration_analysis(file_name_4e);
[nback_count_DWe, nback_responses_DWe, nback_false_responses_DWe, nback_resp_times_DWe] = nBackAnalysis(file_name_4e);
file_name_5e = 'VOW_2.csv';
[vib_count_VOWe, raw_times_VOWe, positive_hits_VOWe, false_times_VOWe, vib_responses_VOWe,vib_resp_times_VOWe] = vibration_analysis(file_name_5e);
[nback_count_VOWe, nback_responses_VOWe, nback_false_responses_VOWe, nback_resp_times_VOWe] = nBackAnalysis(file_name_5e);
file_name_6e = 'NOW_Steven.csv';
[vib_count_NOWe, raw_times_NOWe, positive_hits_NOWe, false_times_NOWe, vib_responses_NOWe,vib_resp_times_NOWe] = vibration_analysis(file_name_6e);
[nback_count_NOWe, nback_responses_NOWe, nback_false_responses_NOWe, nback_resp_times_NOWe] = nBackAnalysis(file_name_6e);
%}
file_name_1a = 'VOS_Steven_NC.csv';
[vib_count_VOSa, raw_times_VOSa, positive_hits_VOSa, false_times_VOSa, vib_responses_VOSa, vib_resp_times_VOSa] = vibration_analysis(file_name_1a);
file_name_2a = 'NOS_Joel.csv';
[vib_count_NOSa, raw_times_NOSa, positive_hits_NOSa, false_times_NOSa, vib_responses_NOSa, vib_resp_times_NOSa] = vibration_analysis(file_name_2a);
[nback_count_NOSa, nback_responses_NOSa, nback_false_responses_NOSa, nback_resp_times_NOSa] = nBackAnalysis(file_name_2a);
file_name_3a = 'DS_Steven_NC.csv';
[vib_count_DSa, raw_times_DSa, positive_hits_DSa, false_times_DSa, vib_responses_DSa, vib_resp_times_DSa] = vibration_analysis(file_name_3a);
[nback_count_DSa, nback_responses_DSa, nback_false_responses_DSa, nback_resp_times_DSa] = nBackAnalysis(file_name_3a);
file_name_4a = 'DW_Steven_NC.csv';
[vib_count_DWa, raw_times_DWa, positive_hits_DWa, false_times_DWa, vib_responses_DWa, vib_resp_times_DWa] = vibration_analysis(file_name_4a);
[nback_count_DWa, nback_responses_DWa, nback_false_responses_DWa, nback_resp_times_DWa] = nBackAnalysis(file_name_4a);
file_name_5a = 'VOW_Steven_NC.csv';
[vib_count_VOWa, raw_times_VOWa, positive_hits_VOWa, false_times_VOWa, vib_responses_VOWa, vib_resp_times_VOWa] = vibration_analysis(file_name_5a);
[nback_count_VOWa, nback_responses_VOWa, nback_false_responses_VOWa, nback_resp_times_VOWa] = nBackAnalysis(file_name_5a);
file_name_6a = 'NOW_Joel.csv';
[vib_count_NOWa, raw_times_NOaW, positive_hits_NOWa, false_times_NOWa, vib_responses_NOWa, vib_resp_times_NOWa] = vibration_analysis(file_name_6a);
[nback_count_NOWa, nback_responses_NOWa, nback_false_responses_NOWa, nback_resp_times_NOWa] = nBackAnalysis(file_name_6a);
file_name_1c = 'VOS_Kyle_NC.csv';
[vib_count_VOS, raw_times_VOS, positive_hits_VOS, false_times_VOS, vib_responses_VOS, vib_resp_times_VOS] = vibration_analysis(file_name_1c);
file_name_2c = 'NOS_Kyle.csv';
[vib_count_NOS, raw_times_NOS, positive_hits_NOS, false_times_NOS, vib_responses_NOS, vib_resp_times_NOS] = vibration_analysis(file_name_2c);
[nback_count_NOS, nback_responses_NOS, nback_false_responses_NOS, nback_resp_times_NOS] = nBackAnalysis(file_name_2c);
file_name_3c = 'DS_Kyle_NC.csv';
[vib_count_DS, raw_times_DS, positive_hits_DS, false_times_DS, vib_responses_DS, vib_resp_times_DS] = vibration_analysis(file_name_3c);
[nback_count_DS, nback_responses_DS, nback_false_responses_DS, nback_resp_times_DS] = nBackAnalysis(file_name_3c);
file_name_4c = 'DW_Kyle_NC.csv';
[vib_count_DW, raw_times_DW, positive_hits_DW, false_times_DW, vib_responses_DW,vib_resp_times_DW] = vibration_analysis(file_name_4c);
[nback_count_DW, nback_responses_DW, nback_false_responses_DW, nback_resp_times_DW] = nBackAnalysis(file_name_4c);
file_name_5c = 'VOW_Kyle_NC.csv';
[vib_count_VOW, raw_times_VOW, positive_hits_VOW, false_times_VOW, vib_responses_VOW,vib_resp_times_VOW] = vibration_analysis(file_name_5c);
[nback_count_VOW, nback_responses_VOW, nback_false_responses_VOW, nback_resp_times_VOW] = nBackAnalysis(file_name_5c);
file_name_6c = 'NOW_Steven.csv';
[vib_count_NOW, raw_times_NOW, positive_hits_NOW, false_times_NOW, vib_responses_NOW,vib_resp_times_NOW] = vibration_analysis(file_name_6c);
[nback_count_NOW, nback_responses_NOW, nback_false_responses_NOW, nback_resp_times_NOW] = nBackAnalysis(file_name_6c);
%{
writematrix(vib_count_VOSa, 'vib_count_VOS_Joel.csv')
writematrix(vib_count_DSa, 'vib_count_DS_Joel.csv')
writematrix(vib_count_VOWa, 'vib_count_VOW_Joel.csv')
writematrix(vib_count_DWa, 'vib_count_DW_Joel.csv')
writematrix(vib_count_VOSb, 'vib_count_VOS_Steven.csv')
writematrix(vib_count_DSb, 'vib_count_DS_Steven.csv')
writematrix(vib_count_VOWb, 'vib_count_VOW_Steven.csv')
writematrix(vib_count_DWb, 'vib_count_DW_Steven.csv')
writematrix(vib_count_VOS, 'vib_count_VOS_Kyle.csv')
writematrix(vib_count_DS, 'vib_count_DS_Kyle.csv')
writematrix(vib_count_VOW, 'vib_count_VOW_Kyle.csv')
writematrix(vib_count_DW, 'vib_count_DW_Kyle.csv')
%}
%% Psychometric Curves
total_vib = 1*10; % number of participants for one curve * 10 (vibrations per intensity)
figure
hold on
% VO
vo_avg = vib_count_VOS(:,2); % add up totals for correct responses
x_data_1 = vib_count_VOS(:,1); % intensity
y_data_1 = vo_avg(:,1)./total_vib; % get total accuracy (correct responses/total vibrations)
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_1, y_data_1, ones(size(y_data_1)));
plot(x_data_1,y_data_1, 'color', 'b', 'LineStyle',"-","marker","o") % raw plot
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "b") % psychometric curve
P1 = findThreshold(curve(:,1),curve(:,2)); %finds the 50% threshold
std_avg_1 = std(transpose([vib_count_VOS(:,2)/10]));
% NB
nb_avg = vib_count_VOW(:,2);
x_data_2 = vib_count_VOW(:,1);
y_data_2 = nb_avg(:,1)./total_vib;
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_2, y_data_2, ones(size(y_data_2)));
plot(x_data_2,y_data_2, 'color', 'r', 'LineStyle',"-","marker","o")
std_avg_2 = std(transpose([vib_count_VOW(:,2)/10]));
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "r")
P2 = findThreshold(curve(:,1),curve(:,2));
vo_avg = vib_count_DS(:,2);
x_data_3 = vib_count_DS(:,1);
y_data_3 = vo_avg(:,1)./total_vib;
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_3, y_data_3, ones(size(y_data_3)));
plot(x_data_3,y_data_3, 'color', 'k', 'LineStyle',"-","marker","o")
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "k")
P3 = findThreshold(curve(:,1),curve(:,2));
vo_avg = vib_count_DW(:,2);
x_data_4 = vib_count_DW(:,1);
y_data_4 = vo_avg(:,1)./total_vib;
[coeffs, curve, threshold] = FitPsycheCurveLogit(x_data_4, y_data_4, ones(size(y_data_4)));
plot(x_data_4,y_data_4, 'color', 'g', 'LineStyle',"-","marker","o")
plot(curve(:,1),curve(:,2),"LineStyle","--", "Color", "g")
P4 = findThreshold(curve(:,1),curve(:,2));
set(gca,'FontSize',14);
title('Psychometric Curves')
legend('VOS Data', 'VOS Curve','VOW Data','VOW Curve', ...
   'DS Data', 'DS Curve','DW Data','DW Curve', "Location", "southeast","FontSize", 14);
xlabel('Vibration Intensity',"Fontsize",14)
ylabel('Vibrations Recognized (Fraction)',"Fontsize",14)
hold off
%table for 50% thresholds
figure
col = {'50% Threshold'};
row = {'VOS','VOW','DS','DW'};
data = {P1;P2;P3;P4};
uitable('columnname',col,'rowname',row,'data',data)
%% Line plot
% 50% threshold
figure
hold on
x1 = [0.4 2.4];
x2 = [0.6 2.6]; % offset
y_sit = [0.1735 0.1850];
y_walk = [0.1951 0.2065];
error_sit = [std([0.172 0.1749]) std([0.175 0.195])];
error_walk = [std([0.2152 0.1749]) std([0.2053 0.2077])];
plot(x1, y_sit,'blue',"marker","o","MarkerSize",10,"LineWidth",2)
errorbar(x1,y_sit,error_sit,'blue')
plot(x2, y_walk,'red',"marker","*","MarkerSize",10,"LineWidth",2)
errorbar(x2,y_walk,error_walk,'red')
s1 = [0.172 0.175];
s2 = [0.1749 0.195];
w1 = [0.2152 0.2053];
w2 = [0.1749 0.2077];
plot(x1, s1, 'blue', 'Marker','o','LineStyle','--')
plot(x1, s2, 'blue', 'Marker','o','LineStyle','--')
plot(x2, w1, 'red', 'Marker','o','LineStyle','--')
plot(x2, w2, 'red', 'Marker','o','LineStyle','--')
%{
scatter(0.4, [0.172 0.1749 0.15 0.1725],'blue','Marker','o') % VOS
scatter(0.6, [0.175 0.195 0.159 0.14],'red','Marker','*') % DS
scatter(2.4, [0.2152 0.1749 0.165 0.1472],'blue','Marker','o') % VOW
scatter(2.6, [0.2053 0.2077 0.1799 0.1423],'red','Marker','*') % DW
%}
title('50% Threshold')
legend('Sitting','Sitting Error','Walking', 'Walking Error', 'Location','best')
xlim([0 3])
xticklabels({'' '' 'No n-back' '' '' 'N-back' ''})
ylabel('50% Threshold')
hold off
% Rxn Time
figure
hold on
y_sit = [0.7987 0.8217];
y_walk = [0.8342 0.9138];
error_sit = [std([mean(vib_resp_times_VOS(:,3)),mean(vib_resp_times_VOSa(:,3))]) std([mean(vib_resp_times_DS(:,3)),mean(vib_resp_times_DSa(:,3))])];
error_walk = [std([mean(vib_resp_times_VOW(:,3)),mean(vib_resp_times_VOWa(:,3))]) std([mean(vib_resp_times_DW(:,3)),mean(vib_resp_times_DWa(:,3))])];
plot(x1, y_sit,'blue',"marker","o","MarkerSize",10,"LineWidth",2)
errorbar(x1,y_sit,error_sit,'blue')
plot(x2, y_walk,'red',"marker","*","MarkerSize",10,"LineWidth",2)
errorbar(x2,y_walk,error_walk,'red')
s1 = [mean(vib_resp_times_VOS(:,3)) mean(vib_resp_times_DS(:,3))];
s2 = [mean(vib_resp_times_VOSa(:,3)) mean(vib_resp_times_DSa(:,3))];
w1 = [mean(vib_resp_times_VOW(:,3)) mean(vib_resp_times_DW(:,3))];
w2 = [mean(vib_resp_times_VOWa(:,3)) mean(vib_resp_times_DWa(:,3))];
plot(x1, s1, 'blue', 'Marker','o','LineStyle','--')
plot(x1, s2, 'blue', 'Marker','o','LineStyle','--')
plot(x2, w1, 'red', 'Marker','o','LineStyle','--')
plot(x2, w2, 'red', 'Marker','o','LineStyle','--')
%{
scatter(0.4, [mean(vib_resp_times_VOS(:,3)) mean(vib_resp_times_VOSa(:,3)) mean(vib_resp_times_VOSb(:,3)) mean(vib_resp_times_VOSe(:,3))],'blue','Marker','o') % VOS
scatter(0.6, [mean(vib_resp_times_DS(:,3)) mean(vib_resp_times_DSa(:,3)) mean(vib_resp_times_DSb(:,3)) mean(vib_resp_times_DSe(:,3))],'red','Marker','*') % DS
scatter(2.4, [mean(vib_resp_times_VOW(:,3)) mean(vib_resp_times_VOWa(:,3)) mean(vib_resp_times_VOWb(:,3)) mean(vib_resp_times_VOWe(:,3))],'blue','Marker','o') % VOW
scatter(2.6, [mean(vib_resp_times_DW(:,3)) mean(vib_resp_times_DWa(:,3)) mean(vib_resp_times_DWb(:,3)) mean(vib_resp_times_DWe(:,3))],'red','Marker','*') % DW
%}
title('Reaction Time')
legend('Sitting','Sitting Error','Walking', 'Walking Error', 'Location','best')
xlim([0 3])
xticklabels({'' '' 'No n-back' '' '' 'N-back' ''})
ylabel('Reaction Time (s)')
hold off
%% Graph the nback response time data
%{
nback_resp_times_moving = graphMovingAvg(nback_resp_times_NOS(:,2),nback_resp_times_NOS(:,3),...
   'nBack Response Times','Response Times');
% Plot the responses and a moving average
nback_responses_moving = graphMovingAvg(nback_responses_NOS(:,1),nback_responses_NOS(:,2),...
   'Correct nBack Responses', 'Correct Responses');
% Plot the moving averages over eachother
figure
yyaxis left
plot(nback_resp_times_NOS(:,2),nback_resp_times_moving,'color','b','Linestyle','--')
ylabel('Response time (s)',"Fontsize",14)
ylim([0,max(nback_resp_times_moving)*1.2])
set(gca,'Ydir','reverse')
hold on
yyaxis right
plot(nback_responses_NOS(:,1),nback_responses_moving,'color','r','Linestyle','--')
ylim([0,max(nback_responses_moving)*1.2])
grid on
legend('Response times', 'Response correctness', "Location", "southeast","FontSize", 14)
title('Moving Averages of Correctness and Response Times')
set(gca,'FontSize',14);
xlabel('Time (s)',"Fontsize",14)
ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
hold off
%}
%% Nback - correct vs. false alarms (sitting)
% Plot the responses and a moving average
%{
nback_false_responses_moving = graphMovingAvg(nback_false_responses_NOS(:,1),nback_false_responses_NOS(:,2),...
   'False Alarm nBack Responses', 'False Alarm Responses');
% Plot the moving averages over eachother
figure
hold on
grid on
plot(nback_responses_NOS(:,1),nback_responses_moving,'color','b','Linestyle','--')
scatter(nback_responses_NOS(:,1),nback_responses_NOS(:,2), 'b')
ylim([0,max(nback_responses_moving)*1.2])
set(gca)
plot(nback_false_responses_NOS(:,1),nback_false_responses_moving,'color','r','Linestyle','--')
scatter(nback_false_responses_NOS(:,1),nback_false_responses_NOS(:,2),'r', 'x')
legend('Correct responses','False Alarm responses', "Location", "southeast","FontSize", 14)
title('Correct vs. False Alarm Responses')
set(gca,'FontSize',14);
xlabel('Time (s)',"Fontsize",14)
ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
hold off
%}
%% Nback only vs. distraction (sitting)
% Plot the responses and a moving average
%{
full_sitting_responses_moving = graphMovingAvg(nback_responses_DS(:,1),nback_responses_DS(:,2),...
   'Correct nBack (with distractions) Responses', 'Correct Responses');
[nback_responses_moving,full_sitting_responses_moving] = graphTwoMovingAvg(nback_responses_NOS,nback_responses_DS, ...
   'Nback Shapes Recognized (Fraction)','Nback only correct responses','Nback with distraction correct responses');
%}
%% Graph the vibration data response times
%vibRespTimesLabels = ['Baseline Data','Baseline Moving Average','With nBack Data','With nBack Moving Average'];
vibRespTimesLabels = {'Baseline Moving Average','With nBack Moving Average'};
%[baseline_RT_ma, vib_w_nback_RT_ma] = graphTwoMovingAvg(vib_resp_times_1,vib_resp_times_2,...
%   'Response Time to Vibrations With and Without nBack',vibRespTimesLabels);
vibResponsesLabels = {'Baseline Moving Average','With nBack Moving Average'};
%[baseline_responses_ma, vib_w_nback_responses_ma] = graphTwoMovingAvg(vib_responses_1,vib_responses_2,...
%   'Response Correctness With and Without nBack ',vibResponsesLabels);
%graphRTHist(raw_times_1,'Responses for Each Vibration Intensity')
%% Graph combined data
% Make a histogram of vibration response times vs. nback response times
histsLabels = {'Vibration Response Times','nBack Response Times'};
%graphTwoHists(vib_resp_times_2(:,2),nback_resp_times(:,2),...
%   'Histogram of Vibration and nBack Response Times',histsLabels);
% Make a histogram comparing the vibration response times between baseline
% and nback
histsLabels = {'Baseline','With nBack'};
% graphTwoHists(vib_resp_times_1(:,2),vib_resp_times_2(:,2),...
%    'Histogram of Vibration and nBack Response Times',histsLabels);
%% 4x1 subplot of histograms - vibration
histSubplot(vib_resp_times_VOS,vib_resp_times_DS,vib_resp_times_VOW,vib_resp_times_DW, ...
   'Vibration Only Sitting','Distraction Sitting','Vibration Only Walking','Distraction Walking')
%% 4x1 subplot of histograms - nback
%histSubplot(nback_resp_times_NOS,nback_resp_times_DS,nback_resp_times_NOW,nback_resp_times_DW,
% 'N-back Only Sitting','Distraction Sitting','N-back Only Walking','Distraction Walking')
%% 4x1 subplot of histograms - shapes
shapeHistSubplot(nback_resp_times_NOS,nback_resp_times_DS,nback_resp_times_NOW,nback_resp_times_DW)
%% Shape Accuracy Bar Graph
shapeAccuracy(nback_responses_NOS,nback_responses_DS,nback_responses_NOW,nback_responses_DW)
%% Cumulative Errors Graphs (six total)
% VO
v1 = cumErrorsVib(vib_responses_VOS,false_times_VOS);
cumErrorsOne(v1,"Vibration Only Sitting Cumulative Errors")
v2 = cumErrorsVib(vib_responses_VOW,false_times_VOW);
cumErrorsOne(v2,"Vibration Only Walkiing Cumulative Errors")
% NO
n1 = cumErrorsNback(nback_responses_NOS,nback_false_responses_NOS);
cumErrorsOne(n1,"N-back Only Sitting Cumulative Errors")
n2 = cumErrorsNback(nback_responses_NOW,nback_false_responses_NOW);
cumErrorsOne(n2,"N-back Only Walking Cumulative Errors")
% D
v3 = cumErrorsVib(vib_responses_DS,false_times_DS);
n3 = cumErrorsNback(nback_responses_DS,nback_false_responses_DS);
cumErrorsTwo(v3,n3,"Distracted Sitting Cumulative Errors")
v4 = cumErrorsVib(vib_responses_DW,false_times_DW);
n4 = cumErrorsNback(nback_responses_DW,nback_false_responses_DW);
cumErrorsTwo(v4,n4,"Distracted Walking Cumulative Errors")
%% 9-stack histogram
%nineStackHist(vib_resp_times_VOS,'VOS Vibration Intensity and Response Time Distribution')
%% Mean and STD for response times of each vibration intensity
%meanStd(vib_resp_times_VOS,'VOS Vibration Intensity and Response Time Mean & Standard Deviation')
%% 45-second phases
%phases(vib_responses_DS,false(positive_hits_DS,false_times_DS),'DS Phases vs. Vibration Correctness')
%phases(nback_responses_DS,nback_false_responses_DS,'DS Phases vs. N-back Correctness')
%% Mean and STD for phases
%phasesMeanStd(vib_resp_times_DS,'DS Phases vs. Vibration Response Time')
%phasesMeanStd(nback_resp_times_DS, 'DS Phases vs. N-back Response Time')
%% Functions
% A function that calls all other functions to analyze vibration data
function [vib_count, raw_times, positive_hits, false_times,vib_responses,vib_resp_times] = vibration_analysis(file_name)
   % Read the file
   [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name);
   % analyze the data
   [vib_count, raw_times, positive_hits,vib_responses,vib_resp_times] = count_vibrations(time, vib_int, vib_but);
   all_hits_time = all_button_hits(time, vib_but);
  
   % Find the time that the false hits occurred
   false_times = setdiff(all_hits_time, positive_hits);
end
% A function that calls other fucntions to analyze nback data
function [nback_count, nback_responses, nback_false_responses, nback_resp_times] = nBackAnalysis(file_name)
   [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name);
   [nback_count, nback_responses, nback_false_responses, nback_resp_times] = count_nback(time, nback_shapes, nback_but)
end
% A function, given filename, stores data in proper form
function [time, nback_shapes, nback_but, vib_int, vib_but] = read_data(file_name)
   data = csvread(file_name, 6, 0);
   time = data(:,1);
   nback_shapes = data(:,2);
   nback_but = data(:,3);
   vib_int = data(:,4);
   vib_but = data(:,5);
end
% A function, given the app data, that calculates the intensities caught
function [vib_count,raw_vib_times,hit_times,vib_responses,vib_resp_times] = count_vibrations(time, vib_int, vib_but)
   vibrations = [0.1; 0.125; 0.15; 0.175; 0.2; 0.225; 0.25; 0.275; 0.3];
   vib_count = zeros(9,2);
   vib_count(:,1) = vibrations;
   num_trials = 10;
   raw_vib_times = zeros(9,num_trials+1);  %for response times
   raw_vib_times(:,1) = vibrations;
   raw_vib_times(:,2:end) = -1;    % initialize the matrix with something that won't be in the data
   hit_times = [];     % to store the time at which the button is hit
   vib_responses = []; % stores whether the user gets a vibration or not
   vib_resp_times = [];    % Stores response times with each time
  
   % start_end_times = zeros(90, 2); % matrix for testing, see if start time of current intensity happens before end time of previous
   i = 1; % indexing through elements
   k = 1; % intensity count
   gap = 3005; % this should be the correct gap time
   while i < size(vib_int,1)-gap
       while vib_int(i)==0 % find first non-zero
           i = i + 1;
           if i > size(vib_int,1) % break if i indexes past array size
               break
           end
       end
      
       if i > size(vib_int,1) % break if i indexes past array size
           break
       end
      
       a = vib_int(i); % get intensity
       start_time = time(i);
      
       b = 0; % default no response
       end_time = 0;
       resp_time = 0;
       for n = i : i+gap % find a "yes" response
           if vib_but(n)==1 && time(n)-start_time < 3.000000
               end_time = time(n);
               hit_times = [hit_times, time(n)];   % append the hit time
               resp_time = end_time-start_time;
              
               if resp_time > 0    % make sure that it's not a false pos
                   b = 1; % change to yes response
                   vib_resp_times = [vib_resp_times; a, start_time, resp_time];
               else
                   disp("There was a 0 vibration response time")
               end
              
               break
           end
       end
      
       [row,~] = find(vib_count(:,1)==a); % update matrix
       vib_count(row,2) = vib_count(row,2) + b; % yes count
       % vib_count(row,3) = vib_count(row,3) + 1; % intensity count
      
       %find the next empty column in the row
       if b == 1
           h = 1;
           while raw_vib_times(row,h) ~= -1 %&& h <= size(raw_times(1,:))
               h = h + 1;
           end
           raw_vib_times(row,h) = resp_time; % response times
       end
      
       vib_responses = [vib_responses; start_time, b];
      
       k = k+1;
       i = i+gap;
   end
   % disp(vib_count)
   %disp(hit_times)
end
% Calculates catches and measures reactions of nbacks
function [nback_count, nback_responses, nback_false_responses, nback_resp_times] = count_nback(time, nback_int, nback_but)
   gap = 2800;     % just less than 3 seconds
   shapes = [0];
   nback_count = 0;
   nback_responses = [];
   nback_false_responses = [];
   nback_resp_times = [];
  
   i = 1; % indexing through elements
   k = 1; % intensity count
   while i < size(nback_int,1)
       start_time = time(i);
       end_time = 0;
       resp_time = 0;
       b = 0;   %default no response
      
       while nback_int(i)==0 % find first non-zero
           i = i + 1;
           if i > size(nback_int,1) % break if i indexes past array size
               break
           end
       end
      
       if i > size(nback_int,1) % break if i indexes past array size
           break
       end       
       curr_shape = nback_int(i);
      
       if curr_shape == shapes(end) % test for n back
          nback_count = nback_count + 1;
          start_time = time(i);
          for n = i : i+gap % find a "yes" response
               if n > size(nback_int,1) % break if i indexes past array size
                   break
               end
               if nback_but(n) == 1
                   end_time = time(n);
                   resp_time = end_time - start_time;
                   if resp_time > 0
                       b = 1;
                       nback_resp_times = [nback_resp_times; curr_shape, start_time, resp_time];
                   else
                       disp("There was a 0 response time nback hit")
                   end
                   break
               end
          end
          nback_responses = [nback_responses; start_time, b, curr_shape];
       end
      
       if curr_shape ~= shapes(end)
          start_time = time(i);
          for n = i : i+gap % find a "yes" response
               if n > size(nback_int,1) % break if i indexes past array size
                   break
               end
               if nback_but(n) == 1
                   end_time = time(n);
                   resp_time = end_time - start_time;
                   if resp_time > 0
                       b = 1;
                   else
                       disp("There was a 0 response time nback hit")
                   end
                   break
               end
          end
           nback_false_responses = [nback_false_responses; start_time, b];
       end
      
       shapes = [shapes, curr_shape];
       k = k+1;
       i = i+gap;
   end
end
% Finds the total number of times the button was pressed and when it was pressed
function all_hits = all_button_hits(time, hit_data)
   all_hits = [];
   i = 0;
  
   % Go through looking for 1's
   while i < length(hit_data)
       if i > 1        % no error if they hit the button from the start
           if hit_data(i) == 1 && hit_data(i-1) == 0
               all_hits = [all_hits,time(i)];
           end
       end
       i = i+1;
   end
end
%% Graph functions
% Graphs moving average with data
function [moving_avg] = graphMovingAvg(x_data,y_data,graphTitle,dataLabel)
   figure
   moving_avg = movmean(y_data,7);
   plot(x_data,y_data,'color','r','Linestyle','None','Marker','o')
   hold on
   %plot(x_data,moving_avg,'color','b','Linestyle','--')
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabel, 'Moving Average', "Location", "southeast","FontSize", 14)
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
   hold off
end
% Graphs two moving averages with data
function [moving_avg1,moving_avg2] = graphTwoMovingAvg(data1,data2,graphTitle,dataLabel1, dataLabel2)
   figure
   moving_avg1 = movmean(data1(:,2),7);
   %plot(data1(:,1),data1(:,2),'color','r','Linestyle','None','Marker','o')
   hold on
   grid on
   plot(data1(:,1),moving_avg1,'color','r','Linestyle','--')
   ylim([0,max(moving_avg1)*1.2])
   set(gca)
  
   moving_avg2 = movmean(data2(:,2),7);
   %plot(data2(:,1),data2(:,2),'color','b','Linestyle','None','Marker','o')
   plot(data2(:,1),moving_avg2,'color','b','Linestyle','--')
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabel1, dataLabel2, "Location", "southeast","FontSize", 14)
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Nback Shapes Recognized (Fraction)',"Fontsize",14)
   hold off
  
end
%Graphs one histogram
function graphRTHist(data,graphTitle,bins)
   edges = linspace(0,max(data(1,:)),bins);
   figure
   dataLabels = {};
   hold on
   for i = 1 : size(data(:,1))
       real_data = [];
       for k = 2 : size(data(i,[2,end]))
           if data(i,k) > 0
               real_data = [real_data, data(i,k)];
           end
       end
       histogram(real_data)%,'BinEdges',edges)
       dataLabels = {dataLabels, int2str(data(i,1))};
   end
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabels, "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
% Graphs two overlapping hisograms
function graphTwoHists(data1,data2,graphTitle,dataLabels)
   bins = 9;
   edges = linspace(0,max(data1),bins);
   figure
   histogram(data1,'BinEdges',edges)%,'BinCounts',bins)
   hold on
   histogram(data2,'BinEdges',edges)%,'BinCounts',bins)
  
   title(graphTitle)
   set(gca,'FontSize',14);
   legend(dataLabels, "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
%plots 4x1 subplot of histograms showing response times for each condition
function histSubplot(data1,data2,data3,data4, title1,title2,title3,title4)
   min_edge = min([min(data1(:,3)), min(data2(:,3)), min(data3(:,3)), min(data4(:,3))]); %find minimum edge
   max_edge = max([max(data1(:,3)), max(data2(:,3)), max(data3(:,3)), max(data4(:,3))]); %find maximum edge
   edges = [min_edge:0.01:max_edge]; %set edges
   max_y = 5; %arbitrary max
  
   figure
   % vibration only sitting
   subplot(4,1,1)
   histogram(data1(:,3),edges)
   ylim([0, max_y]);
   title(title1)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration only walking
   subplot(4,1,2)
   histogram(data2(:,3),edges)
   ylim([0, max_y]);
   title(title2)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,3)
   histogram(data3(:,3),edges)
   ylim([0, max_y]);
   title(title3)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,4)
   histogram(data4(:,3),edges)
   ylim([0, max_y]); 
   title(title4)
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
end
%plots 9 stack histogram showing response times for each intensity for a given condition
function nineStackHist(data,titleLabel)
   a = floor(min(data(:,3))/.1)*.1; %set x min
   b = ceil(max(data(:,3))/.1)*.1; %set x max
   bin_size = 0.05;
   bins = (b-a)/bin_size; %number of bins for each intensity
   matrix = zeros(bins,9); %empty matrix
  
   i = 1;
   while i < (size(data,1)+1) %populating matrix
       if data(i,1) == 0.1 %check vibration intensity
           matrix(bucket(data(i,3),a,bins,bin_size),1) = matrix(bucket(data(i,3),a,bins,bin_size),1)+1; %add to appropriate bin
       elseif data(i,1) == 0.125
           matrix(bucket(data(i,3),a,bins,bin_size),2) = matrix(bucket(data(i,3),a,bins,bin_size),2)+1;   
       elseif data(i,1) == 0.15
           matrix(bucket(data(i,3),a,bins,bin_size),3) = matrix(bucket(data(i,3),a,bins,bin_size),3)+1;   
       elseif data(i,1) == 0.175
           matrix(bucket(data(i,3),a,bins,bin_size),4) = matrix(bucket(data(i,3),a,bins,bin_size),4)+1;   
       elseif data(i,1) == 0.2
           matrix(bucket(data(i,3),a,bins,bin_size),5) = matrix(bucket(data(i,3),a,bins,bin_size),5)+1;   
       elseif data(i,1) == 0.225
           matrix(bucket(data(i,3),a,bins,bin_size),6) =  matrix(bucket(data(i,3),a,bins,bin_size),6)+1;  
       elseif data(i,1) == 0.25
           matrix(bucket(data(i,3),a,bins,bin_size),7) = matrix(bucket(data(i,3),a,bins,bin_size),7)+1; 
       elseif data(i,1) == 0.275
           matrix(bucket(data(i,3),a,bins,bin_size),8) = matrix(bucket(data(i,3),a,bins,bin_size),8)+1;  
       elseif data(i,1) == 0.3
           matrix(bucket(data(i,3),a,bins,bin_size),9) = matrix(bucket(data(i,3),a,bins,bin_size),9)+1;  
       end
       i = i+1;
   end
  
   figure
   x = {}; low = a;
   for i = 1 : bins
       x{i} = [num2str(low),'-',num2str(low+bin_size)];
       low = low+bin_size;
   end
   categories = categorical(x);
   bar(categories,matrix,'stacked')
   set(gca,'FontSize',14);
   title(titleLabel)
   legend("0.1","0.125","0.15","1.75","0.2","0.225","0.25","0.275","0.3", "Location", "northeast","FontSize", 14)
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
   hold off
end
% find which bin the response time falls into
function row = bucket(resp_time,min,bins,bin_size)
   row = 0;
   for i = 1 : bins %iterate through each bin
       if resp_time > min && resp_time < min+bin_size %does response time fit within the specified bin?
           row = i; %return bin if yes
           break
       end
       min = min+bin_size; %if not, move up to next bin
   end
end
%Make a graph and table for the mean and standard deviation of each vibration level’s response time
function meanStd(matrix,titleLabel)
   v1 = [];
   v2 = [];
   v3 = [];
   v4 = [];
   v5 = [];
   v6 = [];
   v7 = [];
   v8 = [];
   v9 = [];
  
 
   i = 1;
   while i < (size(matrix,1)+1) %allocate each response time into arrays based on intensity
       if matrix(i,1) == 0.1
           v1(end+1) = matrix(i,3);
       elseif matrix(i,1) == 0.125
           v2(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.15
           v3(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.175
           v4(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.2
           v5(end+1) = matrix(i,3);   
       elseif matrix(i,1) == 0.225
           v6(end+1) = matrix(i,3);  
       elseif matrix(i,1) == 0.25
           v7(end+1) = matrix(i,3); 
       elseif matrix(i,1) == 0.275
           v8(end+1) = matrix(i,3);  
       elseif matrix(i,1) == 0.3
           v9(end+1) = matrix(i,3);  
       end
       i = i+1;
   end
  
   figure
   x = [0.1,0.125,0.15,0.175,0.2,0.225,0.25,0.275,0.3];
   y = [mean(v1),mean(v2),mean(v3),mean(v4),mean(v5),mean(v6),mean(v7),mean(v8),mean(v9)];
   err = [std(v1),std(v2),std(v3),std(v4),std(v5),std(v6),std(v7),std(v8),std(v9)];
   errorbar(x,y,err)
   set(gca,'FontSize',14);
   title(titleLabel)
   xlabel('Vibration Intensity',"Fontsize",14)
   ylabel('Response Time (s)',"Fontsize",14)
  
   figure
   col = {'0.1','0.125','0.15','0.175','0.2','0.225','0.25','0.275','0.3'};
   row = {'Mean','Standard Deviation'};
   data = {mean(v1) mean(v2) mean(v3) mean(v4) mean(v5) mean(v6) mean(v7) mean(v8) mean(v9);
           std(v1) std(v2) std(v3) std(v4) std(v5) std(v6) std(v7) std(v8) std(v9)};
   uitable('columnname',col,'rowname',row,'data',data,'position',[20 20 800 70])
end
% analyze average response times in 45 second phases, with standard deviation
function phasesMeanStd(data,titleLabel)
   figure
   avg = []; err = [];
   matrix = [];
   limit = 45; k = 1; %45 second phases
   finalTick = ceil(data(end,2)/45);
   x = [45:45:finalTick*45];
   % iterate through each phase
   for i = 1 : finalTick
       while data(k,2) <= limit && k < size(data,1) %make sure to only look at data within the phase, do not index too far (k)
           matrix(end+1) = data(k,3); %append response time to matrix
           k = k + 1; %index to next row
       end
       avg(end+1) = mean(matrix); %find average for phase and append to avg array
       err(end+1) = std(matrix); %find std for phase and append to std array
       limit = limit + 45; %move onto next phase
       matrix = []; %reset matrix for next phase
   end
  
   xLabel = {};
   for i = 1 : finalTick
       xLabel{i} = [num2str(i)];
   end
  
   errorbar(x,avg,err)
   title(titleLabel)
   set(gca,'FontSize',14);
   set(gca,'Xtick',[45 90 135 180 225 270 315 360 405 450]);
   set(gca,'XtickLabel',{'1','2','3','4','5','6','7','8','9','10'});
   xlabel('Phases (per 45 sec)',"Fontsize",14)
   ylabel('Average Response Time (s)',"Fontsize",14)
end
% analyze correctness in 45 second phases
function phases(data,data2,titleLabel)
   figure
   avg = [];
   avg2 = [];
   limit = 45; k = 1; %45 second phases
   correct = 0; total = 0;
   finalTick = ceil(data(end,1)/45);
   x = [45:45:finalTick*45];
  
   % iterate through each phase
   for i = 1 : finalTick
       while data(k,1) <= limit && k < size(data,1) %make sure to only look at data within the phase, do not index too far (k)
           correct = correct + data(k,2); %correct responses
           total = total + 1; %total attempts
           k = k + 1; %index to next row
       end
       avg(end+1) = correct/total; %find proportion
       correct = 0; total = 0; %reset for next phase
       limit = limit + 45; %move onto next phase
   end
  
   %false alarms
   k = 1;
   limit = 45;
   for i = 1 : finalTick
       while data2(k,1) <= limit && k < size(data2,1)
           correct = correct + data2(k,2);
           total = total + 1;
           k = k + 1;
       end
       avg2(end+1) = correct/total;
       correct = 0; total = 0;
       limit = limit + 45;
   end
  
   xLabel = {};
   for i = 1 : finalTick
       xLabel{i} = [num2str(i)];
   end
   plot(x,avg,'color','b','Linestyle','--',"marker","o")
   hold on
   plot(x,avg2,'color','r','Linestyle','--',"marker","o")
   ylim([0,1])
   title(titleLabel)
   set(gca,'FontSize',14);
   set(gca,'Xtick',[45 90 135 180 225 270 315 360 405 450]);
   set(gca,'XtickLabel',{'1','2','3','4','5','6','7','8','9','10'});
   legend('Correct', 'False Alarms', "Location", "southeast","FontSize", 14)
   xlabel('Phases (per 45 sec)',"Fontsize",14)
   ylabel('Responses (Fraction)',"Fontsize",14)
   hold off
end
function vib_false_alarms = false(positive,false) % find vibration false alarms
   p = positive'; p(:,2) = 0;
   f = false'; f(:,2) = 1;
   vib_false_alarms = [p;f];
   vib_false_alarms = sortrows(vib_false_alarms);
end
%plots 4x1 subplot of histograms showing response times for each shape in nback conditions
function shapeHistSubplot(data1,data2,data3,data4)
   min_edge = min([min(data1(:,3)), min(data2(:,3)), min(data3(:,3)), min(data4(:,3))]); %find mininum edge
   max_edge = max([max(data1(:,3)), max(data2(:,3)), max(data3(:,3)), max(data4(:,3))]); %find maximum edge
   edges = [min_edge:0.01:max_edge]; %set edges
   max_y = 5; %arbitrary max
   total = [data1;data2;data3;data4];
  
   s1 = findShapesRespTimes(total,1);
   s2 = findShapesRespTimes(total,2);
   s3 = findShapesRespTimes(total,3);
   s4 = findShapesRespTimes(total,4);
  
   figure
   % vibration only sitting
   subplot(4,1,1)
   histogram(s1,edges)
   ylim([0, max_y]);
   title('Shape 1')
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration only walking
   subplot(4,1,2)
   histogram(s2,edges)
   ylim([0, max_y]);
   title('Shape 2')
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,3)
   histogram(s3,edges)
   ylim([0, max_y]);
   title('Shape 3')
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
  
   % vibration distraction sitting
   subplot(4,1,4)
   histogram(s4,edges)
   ylim([0, max_y]); 
   title('Shape 4')
   set(gca,'FontSize',14);
   xlabel('Response Time (s)',"Fontsize",14)
   ylabel('Distribution',"Fontsize",14)
end
function s = findShapesRespTimes(data,shape)
   s = [];
   for i = 1 : size(data)
       if data(i,1) == shape
           s(end+1) = data(i,3);
       end
   end
end
%histogram of shape accuracy (%)
function shapeAccuracy(data1,data2,data3,data4)
   m = findShapesAccuracy(data1) + findShapesAccuracy(data2) + findShapesAccuracy(data3) + findShapesAccuracy(data4);
   x = categorical({'Shape 1','Shape 2','Shape 3','Shape 4'});
   x = reordercats(x,{'Shape 1','Shape 2','Shape 3','Shape 4'});
   y = [m(1,1)/m(1,2) m(2,1)/m(2,2) m(3,1)/m(3,2) m(4,1)/m(4,2)];
  
   figure
   bar(x,y)
   set(gca,'FontSize',14);
   title("Shape Accuracy")
   xlabel('Shapes',"Fontsize",14)
   ylabel('Accuracy (%)',"Fontsize",14)
   ylim([0.75,1])
end
function m = findShapesAccuracy(data)
   m = [0 0; 0 0; 0 0; 0 0]; % 4 rows for each shape; left column = correct, right column = attempts
   for i = 1 : size(data)
       shape = data(i,3); %find shape number
       resp = data(i,2); %find yes or no response
       if resp == 1 % yes response
           m(shape,1) = m(shape,1) + 1; % add one to correct column
       end   
       m(shape,2) = m(shape,2) + 1; % add one to attempts column
   end
end
%find cumulative errors for nback conditions
function n = cumErrorsNback(responses,false_responses)
   n = [0 0];
   for i = 1 : size(responses)
       if responses(i,2) == 0 %when there is shape but no response
           n(end+1,1) = responses(i,1); %time
       end
   end
   for i = 1 : size(false_responses)
       if false_responses(i,2) == 1 %when there is no shape but yes response
           n(end+1,1) = false_responses(i); %time
       end
   end
   n = sortrows(n); %make sure rows are in correct time order
  
   for i = 1 : size(n)
       n(i,2) = i-1; % add errors for each time, offset by 1 bc matrix starts with [0 0]
   end
end
%find cumulative errors for vibration conditions
function v = cumErrorsVib(responses,false_times)
   v = [0 0]; %start graph at 0,0
   for i = 1 : size(responses)
       if responses(i,2) == 0 %when there is vibration but no response
           v(end+1,1) = responses(i,1); %time
       end
   end
   if size(false_times) > 0
       for i = 1 : size(false_times) %when there is no vibration but yes response
           v(end+1,1) = false_times(i,1); %time
       end
   end
   v = sortrows(v); %make sure rows are in correct time order
  
   for i = 1 : size(v)
       v(i,2) = i-1; % add errors for each time, offset by 1 bc matrix starts with [0 0]
   end
end
%graph cumulative errors for either only vibration or only nback
function cumErrorsOne(data,titleLabel)
   x = data(:,1);
   y = data(:,2);
  
   figure
   plot(x,y,'color','b','Linestyle','--',"marker","o")
   title(titleLabel)
   set(gca,'FontSize',14);
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Errors',"Fontsize",14)
   hold off
end
%graph cumulative errors for both vibration and nback in distracted condition
function cumErrorsTwo(data1,data2,titleLabel)
   x1 = data1(:,1); y1 = data1(:,2);
   x2 = data2(:,1); y2 = data2(:,2);
  
   figure
   plot(x1,y1,'color','b','Linestyle','--',"marker","o")
   hold on
   plot(x2,y2,'color','r','Linestyle','--',"marker","o")
   title(titleLabel)
   set(gca,'FontSize',14);
   xlabel('Time (s)',"Fontsize",14)
   ylabel('Errors',"Fontsize",14)
   legend("Vibration","N-back", "Location", "northeast","FontSize", 14)
   hold off
end
% Psychometric graph function
function [coeffs, curve, threshold] = ...
  FitPsycheCurveLogit(xAxis, yData, weights, targets)
   % Transpose if necessary
   if size(xAxis,1)<size(xAxis,2)
      xAxis=xAxis';
   end
   if size(yData,1)<size(yData,2)
      yData=yData';
   end
   if size(weights,1)<size(weights,2)
      weights=weights';
   end
   % Check range of data
   if min(yData)<0 || max(yData)>1
       % Attempt to normalise data to range 0 to 1
      yData = yData/(mean([min(yData), max(yData)])*2);
   end
   % Perform fit
   coeffs = glmfit(xAxis, [yData, weights], 'binomial','link','logit');
   % Create a new xAxis with higher resolution
   fineX = linspace(min(xAxis),max(xAxis),numel(xAxis)*50);
   % Generate curve from fit
   curve = glmval(coeffs, fineX, 'logit');
   curve = [fineX', curve];     
   % If targets (y) supplied, find threshold (x)
   if nargin==4
   else
      targets = [0.25, 0.50, 0.75];
   end
   threshold = (log(targets./(1-targets))-coeffs(1))/coeffs(2);
end
%find 50% threshold
function p = findThreshold(x,y)
   dy = diff([0;y]);
   dyix = find(dy == 0);
   y(dyix) = y(dyix-1)+1E-8;
   p = interp1(y, x, 0.5);
end